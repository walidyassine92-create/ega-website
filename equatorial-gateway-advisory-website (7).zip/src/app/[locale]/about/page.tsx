import type { Metadata } from "next";
import Image from "next/image";
import { Reveal, Stagger, StaggerItem } from "@/components/Motion";
import { PageHero, StatsBand, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "about", "about");
}

export default async function AboutPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.about.eyebrow} title={dict.about.title} lead={dict.about.lead} image="/images/hero.jpg" />

      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <Reveal>
            <div className="relative aspect-[5/6] overflow-hidden rounded-3xl">
              <Image src="/images/infrastructure.jpg" alt="Large-scale infrastructure in Central Africa at blue hour" fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover" />
            </div>
          </Reveal>
          <div>
            <Reveal>
              <p className="font-serif-display text-2xl italic leading-snug text-petrol-900 dark:text-white lg:text-3xl">{dict.about.body}</p>
            </Reveal>
            <Stagger className="mt-10 space-y-6">
              {dict.about.points.map((p) => (
                <StaggerItem key={p.title}>
                  <div className="flex gap-5">
                    <span className="mt-1 h-10 w-1 shrink-0 rounded-full bg-ember-500" />
                    <div>
                      <h3 className="font-display text-lg font-bold text-petrol-900 dark:text-white">{p.title}</h3>
                      <p className="mt-1.5 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{p.text}</p>
                    </div>
                  </div>
                </StaggerItem>
              ))}
            </Stagger>
          </div>
        </div>
      </section>

      {/* Photo gallery strip — showing EGA's world */}
      <section className="overflow-hidden bg-[var(--bg-soft)] py-16">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <Reveal>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:gap-4">
              {[
                { src: "/images/energy.jpg", alt: "Gas-to-power and energy infrastructure" },
                { src: "/images/mining.jpg", alt: "Mining operations in Central Africa" },
                { src: "/images/agriculture.jpg", alt: "Agricultural landscapes" },
                { src: "/images/logistics.jpg", alt: "Port and logistics infrastructure" },
              ].map((img, i) => (
                <div key={i} className="group relative aspect-[4/3] overflow-hidden rounded-2xl">
                  <Image src={img.src} alt={img.alt} fill sizes="(max-width:768px) 50vw, 25vw" className="object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-petrol-950/20 transition-opacity duration-500 group-hover:opacity-0" />
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <StatsBand dict={dict} />
      <CTASection locale={l} dict={dict} />
    </>
  );
}
