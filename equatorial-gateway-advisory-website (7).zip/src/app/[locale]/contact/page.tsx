import type { Metadata } from "next";
import { Reveal } from "@/components/Motion";
import { PageHero } from "@/components/Sections";
import ContactForm from "@/components/ContactForm";
import AppointmentForm from "@/components/AppointmentForm";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "contact", "contact");
}

export default async function ContactPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);
  const d = dict.contact.details;

  return (
    <>
      <PageHero eyebrow={dict.contact.eyebrow} title={dict.contact.title} lead={dict.contact.lead} />

      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.3fr]">
          <div>
            <Reveal>
              <div className="space-y-8">
                <div>
                  <p className="eyebrow text-ember-600 dark:text-ember-400">{d.email}</p>
                  <a href={`mailto:${d.emailValue}`} className="link-underline mt-2 block font-display text-lg font-bold text-petrol-900 dark:text-white">{d.emailValue}</a>
                </div>
                <div>
                  <p className="eyebrow text-ember-600 dark:text-ember-400">{d.offices}</p>
                  <p className="mt-2 font-display text-lg font-bold text-petrol-900 dark:text-white">{d.officesValue}</p>
                </div>
                <div>
                  <p className="eyebrow text-ember-600 dark:text-ember-400">{d.hours}</p>
                  <p className="mt-2 font-display text-lg font-bold text-petrol-900 dark:text-white">{d.hoursValue}</p>
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.1}>
              <div className="mt-10">
                <AppointmentForm locale={l} dict={dict} />
              </div>
            </Reveal>
          </div>

          <Reveal delay={0.05}>
            <ContactForm locale={l} dict={dict} />
          </Reveal>
        </div>
      </section>
    </>
  );
}
