import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Reveal } from "@/components/Motion";
import { InsightsGrid, CTASection } from "@/components/Sections";
import { insights, t } from "@/lib/data";
import { locales } from "@/i18n/config";
import { getDictionary } from "@/i18n/dictionaries";
import { resolveLocale } from "@/lib/meta";

export function generateStaticParams() {
  return locales.flatMap((locale) => insights.map((a) => ({ locale, id: a.id })));
}

export async function generateMetadata({ params }: { params: Promise<{ locale: string; id: string }> }): Promise<Metadata> {
  const { locale, id } = await params;
  const l = resolveLocale(locale);
  const article = insights.find((a) => a.id === id);
  if (!article) return {};
  const url = `/${l}/insights/${id}`;
  return {
    title: `${t(article.title, l)} — EGA Insights`,
    description: t(article.excerpt, l),
    alternates: { canonical: url, languages: { en: `/en/insights/${id}`, fr: `/fr/insights/${id}`, de: `/de/insights/${id}` } },
    openGraph: { type: "article", title: t(article.title, l), description: t(article.excerpt, l), url },
  };
}

export default async function InsightArticle({ params }: { params: Promise<{ locale: string; id: string }> }) {
  const { locale, id } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);
  const article = insights.find((a) => a.id === id);
  if (!article) notFound();

  const dateStr = new Date(article.date).toLocaleDateString(l, { year: "numeric", month: "long", day: "numeric" });

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: t(article.title, l),
    description: t(article.excerpt, l),
    datePublished: article.date,
    author: { "@type": "Organization", name: "Equatorial Gateway Advisory" },
    publisher: { "@type": "Organization", name: "Equatorial Gateway Advisory" },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <article className="relative overflow-hidden bg-petrol-950 pb-16 pt-36 text-white lg:pt-44">
        <div className="grid-veil pointer-events-none absolute inset-0 opacity-20" />
        <div className="relative mx-auto max-w-3xl px-5 lg:px-10">
          <Link href={`/${l}/insights`} className="link-underline mb-8 inline-flex items-center gap-2 text-sm font-medium text-petrol-300">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M11 18l-6-6 6-6" /></svg>
            {dict.insightsPage.title}
          </Link>
          <div className="mb-6 flex flex-wrap items-center gap-3 text-xs">
            <span className="rounded-full bg-ember-500/15 px-3 py-1 font-semibold uppercase tracking-wide text-ember-300">{t(article.category, l)}</span>
            <span className="text-petrol-300">{dateStr}</span>
            <span className="text-petrol-300">· {article.readMin} {dict.insightsSection.min}</span>
          </div>
          <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tightest sm:text-4xl lg:text-5xl">{t(article.title, l)}</h1>
        </div>
      </article>

      <section className="mx-auto max-w-3xl px-5 py-16 lg:px-10 lg:py-24">
        <Reveal>
          <p className="font-serif-display text-xl italic leading-relaxed text-petrol-900 dark:text-white lg:text-2xl">{t(article.excerpt, l)}</p>
        </Reveal>
        <Reveal delay={0.05}>
          <p className="mt-8 text-base leading-relaxed text-slatey-700 dark:text-petrol-200">{t(article.body, l)}</p>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="mt-12 rounded-3xl border bg-[var(--bg-soft)] p-8">
            <p className="font-display text-lg font-bold text-petrol-900 dark:text-white">{dict.cta.title}</p>
            <p className="mt-2 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{dict.cta.subtitle}</p>
            <Link href={`/${l}/contact`} className="mt-5 inline-flex items-center gap-2 rounded-full bg-ember-500 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-ember-400">
              {dict.cta.primary}
            </Link>
          </div>
        </Reveal>
      </section>

      <section className="mx-auto max-w-[1400px] px-5 pb-24 lg:px-10 lg:pb-32">
        <h2 className="mb-10 font-display text-2xl font-bold text-petrol-900 dark:text-white">{dict.insightsSection.cta}</h2>
        <InsightsGrid locale={l} dict={dict} limit={3} />
      </section>

      <CTASection locale={l} dict={dict} />
    </>
  );
}
