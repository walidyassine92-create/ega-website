import type { Metadata } from "next";
import { PageHero, InsightsGrid, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "insights", "insights");
}

export default async function InsightsPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.insightsPage.eyebrow} title={dict.insightsPage.title} lead={dict.insightsPage.lead} image="/images/digital.jpg" />
      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <InsightsGrid locale={l} dict={dict} />
      </section>
      <CTASection locale={l} dict={dict} />
    </>
  );
}
