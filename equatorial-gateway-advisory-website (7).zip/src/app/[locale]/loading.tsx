import { CompassMark } from "@/components/Brand";

export default function Loading() {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-petrol-950">
      <CompassMark className="compass-spin h-16 w-16 text-white/80" />
      <p className="mt-6 text-[10px] font-semibold uppercase tracking-[0.32em] text-petrol-300">Equatorial Gateway Advisory</p>
    </div>
  );
}
