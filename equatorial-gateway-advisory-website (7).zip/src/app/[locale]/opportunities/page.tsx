import type { Metadata } from "next";
import { PageHero, OpportunityExplorer, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "opportunities", "opportunities");
}

export default async function OpportunitiesPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.oppPage.eyebrow} title={dict.oppPage.title} lead={dict.oppPage.lead} image="/images/boardroom.jpg" />
      <section className="mx-auto max-w-[1400px] px-5 py-20 lg:px-10 lg:py-28">
        <OpportunityExplorer locale={l} dict={dict} />
      </section>
      <CTASection locale={l} dict={dict} />
    </>
  );
}
