import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import Hero from "@/components/Hero";
import { Reveal } from "@/components/Motion";
import {
  Marquee,
  StatsBand,
  SectionHeading,
  SectorsGrid,
  CountryExplorer,
  OpportunityGrid,
  ProcessTimeline,
  InsightsGrid,
  CTASection,
} from "@/components/Sections";
import { isLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/dictionaries";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const l = (isLocale(locale) ? locale : "en") as Locale;
  const dict = getDictionary(l);
  return {
    title: dict.meta.home.title,
    description: dict.meta.home.description,
    alternates: { canonical: `/${l}`, languages: { en: "/en", fr: "/fr", de: "/de" } },
    openGraph: { title: dict.meta.home.title, description: dict.meta.home.description, url: `/${l}` },
  };
}

export default async function Home({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = locale as Locale;
  const dict = getDictionary(l);
  const href = (p: string) => `/${l}/${p}`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: "Equatorial Gateway Advisory",
    alternateName: "EGA",
    description: dict.meta.home.description,
    email: "contact@equatorialgatewayadvisory.com",
    areaServed: ["Republic of Congo", "Cameroon", "Gabon", "DR Congo", "Equatorial Guinea", "Chad", "Central African Republic", "Angola"],
    serviceType: "Investment Advisory",
    url: "https://www.equatorialgatewayadvisory.com",
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Hero locale={l} dict={dict} />
      <Marquee items={dict.marquee} />

      {/* About */}
      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div>
            <SectionHeading eyebrow={dict.about.eyebrow} title={dict.about.title} />
            <Reveal delay={0.1}>
              <p className="mt-6 text-base leading-relaxed text-slatey-600 dark:text-petrol-200">{dict.about.lead}</p>
            </Reveal>
            <Reveal delay={0.15}>
              <p className="mt-4 text-base leading-relaxed text-slatey-600 dark:text-petrol-200">{dict.about.body}</p>
            </Reveal>
            <Reveal delay={0.2}>
              <div className="mt-8 grid gap-6 sm:grid-cols-3">
                {dict.about.points.map((p) => (
                  <div key={p.title} className="border-t-2 border-ember-500 pt-4">
                    <h3 className="font-display text-base font-bold text-petrol-900 dark:text-white">{p.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{p.text}</p>
                  </div>
                ))}
              </div>
            </Reveal>
            <Reveal delay={0.25}>
              <Link href={href("about")} className="link-underline mt-9 inline-flex items-center gap-2 text-sm font-semibold text-ember-500">
                {dict.about.cta}
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </Link>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <div className="relative aspect-[4/5] overflow-hidden rounded-3xl">
              <Image src="/images/boardroom.jpg" alt="Executives in a boardroom at dusk overlooking an African skyline" fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-petrol-950/50 to-transparent" />
              <div className="glass absolute bottom-5 left-5 right-5 rounded-2xl border p-5">
                <p className="font-serif-display text-lg italic text-petrol-900 dark:text-white">&ldquo;{dict.cta.title}&rdquo;</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <StatsBand dict={dict} />

      {/* Sectors */}
      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading eyebrow={dict.sectorsSection.eyebrow} title={dict.sectorsSection.title} subtitle={dict.sectorsSection.subtitle} />
          <Reveal>
            <Link href={href("sectors")} className="link-underline hidden shrink-0 items-center gap-2 text-sm font-semibold text-ember-500 sm:inline-flex">
              {dict.sectorsSection.cta}
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </Link>
          </Reveal>
        </div>
        <div className="mt-14">
          <SectorsGrid locale={l} dict={dict} />
        </div>
      </section>

      {/* Cinematic image strip */}
      <section className="overflow-hidden py-4">
        <Reveal>
          <div className="mx-auto grid max-w-[1400px] grid-cols-2 gap-3 px-5 md:grid-cols-5 lg:px-10">
            {[
              { src: "/images/energy.jpg", alt: "Energy infrastructure" },
              { src: "/images/mining.jpg", alt: "Mining operations" },
              { src: "/images/agriculture.jpg", alt: "Agricultural landscapes" },
              { src: "/images/digital.jpg", alt: "Data centre technology" },
              { src: "/images/logistics.jpg", alt: "Port logistics" },
            ].map((img, i) => (
              <div key={i} className="group relative aspect-[3/2] overflow-hidden rounded-2xl">
                <Image src={img.src} alt={img.alt} fill sizes="(max-width:768px) 50vw, 20vw" className="object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-petrol-950/30 transition-opacity duration-500 group-hover:opacity-0" />
              </div>
            ))}
          </div>
        </Reveal>
      </section>

      {/* Why Central Africa */}
      <section className="bg-[var(--bg-soft)] py-24 lg:py-32">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <SectionHeading eyebrow={dict.whySection.eyebrow} title={dict.whySection.title} subtitle={dict.whySection.subtitle} />
          <div className="mt-14">
            <CountryExplorer locale={l} dict={dict} />
          </div>
        </div>
      </section>

      {/* Opportunities */}
      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading eyebrow={dict.oppSection.eyebrow} title={dict.oppSection.title} subtitle={dict.oppSection.subtitle} />
          <Reveal>
            <Link href={href("opportunities")} className="link-underline hidden shrink-0 items-center gap-2 text-sm font-semibold text-ember-500 sm:inline-flex">
              {dict.oppSection.cta}
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </Link>
          </Reveal>
        </div>
        <div className="mt-14">
          <OpportunityGrid locale={l} dict={dict} items={undefined} />
        </div>
      </section>

      {/* Process */}
      <section className="relative overflow-hidden bg-[var(--bg-soft)] py-24 lg:py-32">
        <div className="mx-auto max-w-[1100px] px-5 lg:px-10">
          <SectionHeading eyebrow={dict.processSection.eyebrow} title={dict.processSection.title} subtitle={dict.processSection.subtitle} center />
          <div className="mt-16">
            <ProcessTimeline locale={l} />
          </div>
        </div>
      </section>

      {/* Insights */}
      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading eyebrow={dict.insightsSection.eyebrow} title={dict.insightsSection.title} subtitle={dict.insightsSection.subtitle} />
          <Reveal>
            <Link href={href("insights")} className="link-underline hidden shrink-0 items-center gap-2 text-sm font-semibold text-ember-500 sm:inline-flex">
              {dict.insightsSection.cta}
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </Link>
          </Reveal>
        </div>
        <div className="mt-14">
          <InsightsGrid locale={l} dict={dict} limit={3} />
        </div>
      </section>

      <CTASection locale={l} dict={dict} />
    </>
  );
}
