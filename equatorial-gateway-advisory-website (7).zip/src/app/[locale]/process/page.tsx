import type { Metadata } from "next";
import { PageHero, ProcessTimeline, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "process", "process");
}

export default async function ProcessPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.processPage.eyebrow} title={dict.processPage.title} lead={dict.processPage.lead} image="/images/infrastructure.jpg" />
      <section className="mx-auto max-w-[1100px] px-5 py-24 lg:px-10 lg:py-32">
        <ProcessTimeline locale={l} />
      </section>
      <CTASection locale={l} dict={dict} />
    </>
  );
}
