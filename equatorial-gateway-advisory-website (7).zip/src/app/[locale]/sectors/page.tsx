import type { Metadata } from "next";
import { PageHero, SectorsFeatured, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "sectors", "sectors");
}

export default async function SectorsPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.sectorsPage.eyebrow} title={dict.sectorsPage.title} lead={dict.sectorsPage.lead} image="/images/sectors.jpg" />
      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <SectorsFeatured locale={l} dict={dict} />
      </section>
      <CTASection locale={l} dict={dict} />
    </>
  );
}
