import type { Metadata } from "next";
import { Stagger, StaggerItem } from "@/components/Motion";
import { PageHero, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "services", "services");
}

export default async function ServicesPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.servicesPage.eyebrow} title={dict.servicesPage.title} lead={dict.servicesPage.lead} image="/images/boardroom.jpg" />

      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <Stagger className="grid gap-px overflow-hidden rounded-3xl border bg-[var(--line)] sm:grid-cols-2 lg:grid-cols-3">
          {dict.servicesPage.items.map((item, i) => (
            <StaggerItem key={item.title} className="group relative bg-[var(--card)] p-8 transition-colors hover:bg-ember-500/[0.04]">
              <span className="font-display text-sm font-bold text-ember-500">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-4 font-display text-xl font-bold text-petrol-900 dark:text-white">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{item.text}</p>
              <span className="absolute bottom-0 left-0 h-0.5 w-0 bg-ember-500 transition-all duration-500 group-hover:w-full" />
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      <CTASection locale={l} dict={dict} />
    </>
  );
}
