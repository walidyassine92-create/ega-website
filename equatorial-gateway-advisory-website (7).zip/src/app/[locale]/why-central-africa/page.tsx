import type { Metadata } from "next";
import { Stagger, StaggerItem } from "@/components/Motion";
import { PageHero, CountryExplorer, SectionHeading, CTASection } from "@/components/Sections";
import { getDictionary } from "@/i18n/dictionaries";
import { pageMeta, resolveLocale } from "@/lib/meta";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  return pageMeta(locale, "why", "why-central-africa");
}

export default async function WhyPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = resolveLocale(locale);
  const dict = getDictionary(l);

  return (
    <>
      <PageHero eyebrow={dict.whyPage.eyebrow} title={dict.whyPage.title} lead={dict.whyPage.lead} image="/images/agriculture.jpg" />

      <section className="mx-auto max-w-[1400px] px-5 py-24 lg:px-10 lg:py-32">
        <Stagger className="grid gap-6 sm:grid-cols-2">
          {dict.whyPage.pillars.map((p, i) => (
            <StaggerItem key={p.title}>
              <div className="lift flex h-full gap-6 rounded-3xl border bg-[var(--card)] p-8 hover:border-ember-400">
                <span className="font-display text-4xl font-extrabold text-ember-500/30">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <h3 className="font-display text-xl font-bold text-petrol-900 dark:text-white">{p.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{p.text}</p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      <section className="bg-[var(--bg-soft)] py-24 lg:py-32">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <SectionHeading eyebrow={dict.whySection.eyebrow} title={dict.whyPage.countriesTitle} />
          <div className="mt-14">
            <CountryExplorer locale={l} dict={dict} />
          </div>
        </div>
      </section>

      <CTASection locale={l} dict={dict} />
    </>
  );
}
