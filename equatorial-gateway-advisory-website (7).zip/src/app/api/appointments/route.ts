import { db } from "@/db";
import { appointments } from "@/db/schema";

export const dynamic = "force-dynamic";

function clean(v: unknown, max = 2000): string | null {
  if (typeof v !== "string") return null;
  const trimmed = v.trim().slice(0, max);
  return trimmed.length ? trimmed : null;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = clean(body.name, 160);
    const email = clean(body.email, 200);

    if (!name || !email || !email.includes("@")) {
      return Response.json({ ok: false, error: "Invalid submission" }, { status: 400 });
    }

    await db.insert(appointments).values({
      name,
      email,
      organisation: clean(body.organisation, 200),
      preferredDate: clean(body.preferredDate, 40),
      topic: clean(body.topic, 200),
      notes: clean(body.notes, 4000),
      locale: clean(body.locale, 8) ?? "en",
    });

    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
