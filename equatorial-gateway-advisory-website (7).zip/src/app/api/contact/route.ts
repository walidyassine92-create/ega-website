import { db } from "@/db";
import { contactSubmissions } from "@/db/schema";

export const dynamic = "force-dynamic";

function clean(v: unknown, max = 2000): string | null {
  if (typeof v !== "string") return null;
  const trimmed = v.trim().slice(0, max);
  return trimmed.length ? trimmed : null;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = clean(body.name, 160);
    const email = clean(body.email, 200);
    const message = clean(body.message, 5000);

    if (!name || !email || !message || !email.includes("@")) {
      return Response.json({ ok: false, error: "Invalid submission" }, { status: 400 });
    }

    await db.insert(contactSubmissions).values({
      name,
      email,
      message,
      company: clean(body.company, 200),
      country: clean(body.country, 120),
      phone: clean(body.phone, 60),
      sector: clean(body.sector, 120),
      budget: clean(body.budget, 120),
      locale: clean(body.locale, 8) ?? "en",
    });

    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
