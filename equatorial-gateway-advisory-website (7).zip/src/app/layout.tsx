import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Manrope, Fraunces } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope", display: "swap" });
const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-fraunces", display: "swap", style: ["normal", "italic"] });

const SITE = "https://www.equatorialgatewayadvisory.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: {
    default: "Equatorial Gateway Advisory — Connecting Global Capital with Central African Opportunities",
    template: "%s",
  },
  description:
    "EGA facilitates strategic investment across the Republic of Congo and Central Africa through trusted advisory, institutional relationships and disciplined project execution.",
  keywords: [
    "Central Africa investment",
    "Republic of Congo investment advisory",
    "investment facilitation Africa",
    "government relations Africa",
    "private equity Central Africa",
    "sovereign fund Africa",
    "Equatorial Gateway Advisory",
  ],
  authors: [{ name: "Equatorial Gateway Advisory" }],
  openGraph: {
    type: "website",
    siteName: "Equatorial Gateway Advisory",
    images: [{ url: "/images/og.jpg", width: 1200, height: 630, alt: "Equatorial Gateway Advisory" }],
  },
  twitter: {
    card: "summary_large_image",
    images: ["/images/og.jpg"],
  },
  icons: {
    icon: [{ url: "/favicon.svg", type: "image/svg+xml" }],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('ega-theme');var d=t? t==='dark' : true;document.documentElement.classList.toggle('dark', d);}catch(e){document.documentElement.classList.add('dark');}})();`,
          }}
        />
      </head>
      <body className={`${inter.variable} ${manrope.variable} ${fraunces.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  );
}
