import Link from "next/link";
import { CompassMark } from "@/components/Brand";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-petrol-950 px-6 text-center text-white">
      <CompassMark className="h-16 w-16 text-white/70" />
      <p className="mt-8 font-display text-6xl font-extrabold tracking-tightest">404</p>
      <p className="mt-3 max-w-sm text-petrol-200">This page has drifted off the map. Let us guide you back.</p>
      <Link href="/en" className="mt-8 rounded-full bg-ember-500 px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-ember-400">
        Back to home
      </Link>
    </div>
  );
}
