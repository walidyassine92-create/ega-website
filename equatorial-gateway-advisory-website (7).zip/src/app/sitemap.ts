import type { MetadataRoute } from "next";
import { locales } from "@/i18n/config";
import { allRoutes } from "@/lib/routes";
import { insights } from "@/lib/data";

const BASE = "https://www.equatorialgatewayadvisory.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const pages: MetadataRoute.Sitemap = [];

  for (const locale of locales) {
    for (const route of allRoutes) {
      pages.push({
        url: `${BASE}/${locale}${route ? `/${route}` : ""}`,
        lastModified: now,
        changeFrequency: route === "" ? "weekly" : "monthly",
        priority: route === "" ? 1 : 0.7,
      });
    }
    for (const article of insights) {
      pages.push({
        url: `${BASE}/${locale}/insights/${article.id}`,
        lastModified: new Date(article.date),
        changeFrequency: "yearly",
        priority: 0.6,
      });
    }
  }

  return pages;
}
