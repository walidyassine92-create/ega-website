"use client";

import { useState } from "react";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

export default function AppointmentForm({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const a = dict.appointment;
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, locale }),
      });
      if (!res.ok) throw new Error();
      setStatus("success");
      form.reset();
    } catch {
      setStatus("error");
    }
  }

  const field = "w-full rounded-xl border bg-[var(--bg)] px-4 py-3 text-sm text-petrol-900 placeholder:text-slatey-400 focus:border-ember-400 focus:outline-none focus:ring-2 focus:ring-ember-500/20 dark:text-white dark:placeholder:text-petrol-300";
  const label = "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slatey-500 dark:text-petrol-200";

  if (status === "success") {
    return (
      <div className="rounded-3xl border bg-[var(--card)] p-8 text-center">
        <p className="font-display text-lg font-bold text-petrol-900 dark:text-white">{a.success}</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-3xl border bg-[var(--card)] p-7 lg:p-8">
      <h3 className="font-display text-xl font-bold text-petrol-900 dark:text-white">{a.title}</h3>
      <p className="mt-2 text-sm text-slatey-600 dark:text-petrol-200">{a.lead}</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div>
          <label className={label} htmlFor="ap-name">{a.name} *</label>
          <input id="ap-name" name="name" required className={field} />
        </div>
        <div>
          <label className={label} htmlFor="ap-email">{a.email} *</label>
          <input id="ap-email" name="email" type="email" required className={field} />
        </div>
        <div>
          <label className={label} htmlFor="ap-org">{a.organisation}</label>
          <input id="ap-org" name="organisation" className={field} />
        </div>
        <div>
          <label className={label} htmlFor="ap-date">{a.date}</label>
          <input id="ap-date" name="preferredDate" type="date" className={field} />
        </div>
        <div className="sm:col-span-2">
          <label className={label} htmlFor="ap-topic">{a.topic}</label>
          <input id="ap-topic" name="topic" className={field} />
        </div>
        <div className="sm:col-span-2">
          <label className={label} htmlFor="ap-notes">{a.notes}</label>
          <textarea id="ap-notes" name="notes" rows={3} className={`${field} resize-none`} />
        </div>
      </div>
      {status === "error" && <p className="mt-4 text-sm text-ember-600">{dict.contact.form.error}</p>}
      <button disabled={status === "sending"} className="mt-6 w-full rounded-full bg-petrol-800 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-ember-500 disabled:opacity-60 dark:bg-white dark:text-petrol-900 dark:hover:bg-ember-500 dark:hover:text-white">
        {status === "sending" ? dict.contact.form.sending : a.submit}
      </button>
    </form>
  );
}
