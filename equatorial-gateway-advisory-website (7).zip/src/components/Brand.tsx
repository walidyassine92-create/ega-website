export function CompassMark({ className = "", spin = false }: { className?: string; spin?: boolean }) {
  return (
    <svg viewBox="0 0 120 120" className={className} role="img" aria-label="EGA compass mark" fill="none">
      <g className={spin ? "compass-spin" : ""} style={{ transformOrigin: "60px 60px" }}>
        <circle cx="60" cy="60" r="46" stroke="currentColor" strokeOpacity="0.25" strokeWidth="2" strokeDasharray="2 7" />
        {/* four-point compass star */}
        <path d="M60 10 L67 53 L60 60 L53 53 Z" fill="currentColor" />
        <path d="M60 110 L53 67 L60 60 L67 67 Z" fill="currentColor" opacity="0.7" />
        <path d="M10 60 L53 53 L60 60 L53 67 Z" fill="currentColor" opacity="0.55" />
        <path d="M110 60 L67 67 L60 60 L67 53 Z" fill="currentColor" opacity="0.55" />
      </g>
      {/* ascending ember arrow */}
      <path
        d="M22 92 L48 66 L62 78 L92 40"
        stroke="var(--color-ember-500)"
        strokeWidth="6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M78 40 L92 40 L92 54" stroke="var(--color-ember-500)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <CompassMark className="h-9 w-9 text-petrol-700 dark:text-petrol-100 shrink-0" />
      {!compact && (
        <span className="leading-none">
          <span className="block font-display text-xl font-extrabold tracking-tightest text-petrol-800 dark:text-white">EGA</span>
          <span className="block text-[9px] font-semibold uppercase tracking-[0.24em] text-slatey-500 dark:text-petrol-200">
            Equatorial Gateway Advisory
          </span>
        </span>
      )}
    </span>
  );
}
