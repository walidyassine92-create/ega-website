"use client";

import { useState } from "react";
import { sectors, t } from "@/lib/data";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

type Status = "idle" | "sending" | "success" | "error";

export default function ContactForm({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const [status, setStatus] = useState<Status>("idle");
  const f = dict.contact.form;

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, locale }),
      });
      if (!res.ok) throw new Error();
      setStatus("success");
      form.reset();
    } catch {
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="flex h-full min-h-[420px] flex-col items-center justify-center rounded-3xl border bg-[var(--card)] p-10 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-ember-500/10 text-ember-500">
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 6L9 17l-5-5" /></svg>
        </div>
        <p className="mt-6 max-w-sm font-display text-xl font-bold text-petrol-900 dark:text-white">{f.success}</p>
      </div>
    );
  }

  const field = "w-full rounded-xl border bg-[var(--bg)] px-4 py-3 text-sm text-petrol-900 placeholder:text-slatey-400 transition-colors focus:border-ember-400 focus:outline-none focus:ring-2 focus:ring-ember-500/20 dark:text-white dark:placeholder:text-petrol-300";
  const label = "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slatey-500 dark:text-petrol-200";

  return (
    <form onSubmit={onSubmit} className="rounded-3xl border bg-[var(--card)] p-7 lg:p-9">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className={label} htmlFor="name">{f.name} *</label>
          <input id="name" name="name" required className={field} autoComplete="name" />
        </div>
        <div>
          <label className={label} htmlFor="company">{f.company}</label>
          <input id="company" name="company" className={field} autoComplete="organization" />
        </div>
        <div>
          <label className={label} htmlFor="country">{f.country}</label>
          <input id="country" name="country" className={field} autoComplete="country-name" />
        </div>
        <div>
          <label className={label} htmlFor="phone">{f.phone}</label>
          <input id="phone" name="phone" type="tel" className={field} autoComplete="tel" />
        </div>
        <div>
          <label className={label} htmlFor="email">{f.email} *</label>
          <input id="email" name="email" type="email" required className={field} autoComplete="email" />
        </div>
        <div>
          <label className={label} htmlFor="sector">{f.sector}</label>
          <select id="sector" name="sector" defaultValue="" className={field}>
            <option value="" disabled>{f.sectorPlaceholder}</option>
            {sectors.map((s) => (
              <option key={s.id} value={t(s.name, "en")}>{t(s.name, locale)}</option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className={label} htmlFor="budget">{f.budget}</label>
          <select id="budget" name="budget" defaultValue="" className={field}>
            <option value="" disabled>{f.budgetPlaceholder}</option>
            {dict.contact.budgets.map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className={label} htmlFor="message">{f.message} *</label>
          <textarea id="message" name="message" required rows={4} className={`${field} resize-none`} />
        </div>
      </div>

      {status === "error" && <p className="mt-4 text-sm text-ember-600">{f.error}</p>}

      <button
        type="submit"
        disabled={status === "sending"}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-ember-500 px-7 py-4 text-sm font-semibold text-white transition-all hover:bg-ember-400 disabled:opacity-60 sm:w-auto"
      >
        {status === "sending" ? f.sending : f.submit}
        {status !== "sending" && (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
        )}
      </button>
    </form>
  );
}
