"use client";

import Link from "next/link";
import { useState } from "react";
import { CompassMark } from "./Brand";
import { navItems } from "@/lib/routes";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

export default function Footer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const href = (p: string) => `/${locale}${p ? `/${p}` : ""}`;
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const year = new Date().getFullYear();

  return (
    <footer className="relative overflow-hidden bg-petrol-950 text-petrol-100">
      <div className="grid-veil pointer-events-none absolute inset-0 opacity-30" />
      <div className="relative mx-auto max-w-[1400px] px-5 py-20 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1.4fr]">
          <div>
            <div className="flex items-center gap-3">
              <CompassMark className="h-11 w-11 text-white" />
              <div>
                <p className="font-display text-2xl font-extrabold tracking-tightest text-white">EGA</p>
                <p className="text-[10px] uppercase tracking-[0.24em] text-petrol-300">Equatorial Gateway Advisory</p>
              </div>
            </div>
            <p className="mt-6 max-w-xs text-sm leading-relaxed text-petrol-200">{dict.footer.tagline}</p>
            <a
              href="mailto:contact@equatorialgatewayadvisory.com"
              className="link-underline mt-6 inline-block text-sm font-medium text-ember-300"
            >
              contact@equatorialgatewayadvisory.com
            </a>
          </div>

          <div>
            <p className="eyebrow mb-5 text-petrol-400">{dict.footer.explore}</p>
            <ul className="space-y-3 text-sm">
              <li><Link href={href("")} className="text-petrol-200 transition-colors hover:text-white">{dict.nav.home}</Link></li>
              {navItems.slice(0, 4).map((i) => (
                <li key={i.key}><Link href={href(i.path)} className="text-petrol-200 transition-colors hover:text-white">{dict.nav[i.key]}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-5 text-petrol-400">{dict.footer.company}</p>
            <ul className="space-y-3 text-sm">
              {navItems.slice(4).map((i) => (
                <li key={i.key}><Link href={href(i.path)} className="text-petrol-200 transition-colors hover:text-white">{dict.nav[i.key]}</Link></li>
              ))}
              <li><Link href={href("portal")} className="text-petrol-200 transition-colors hover:text-white">{dict.nav.portal}</Link></li>
              <li><Link href={href("contact")} className="text-petrol-200 transition-colors hover:text-white">{dict.nav.contact}</Link></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-5 text-petrol-400">{dict.footer.newsletter}</p>
            <p className="mb-4 text-sm leading-relaxed text-petrol-200">{dict.footer.newsletterText}</p>
            {done ? (
              <p className="rounded-xl border border-ember-400/40 bg-ember-500/10 px-4 py-3 text-sm text-ember-200">
                {dict.footer.subscribed}
              </p>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (email.includes("@")) setDone(true);
                }}
                className="flex flex-col gap-2.5 sm:flex-row"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={dict.footer.emailPlaceholder}
                  aria-label={dict.footer.emailPlaceholder}
                  className="min-w-0 flex-1 rounded-full border border-petrol-700 bg-petrol-900/60 px-4 py-3 text-sm text-white placeholder:text-petrol-400 focus:border-ember-400 focus:outline-none"
                />
                <button className="rounded-full bg-ember-500 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-ember-400">
                  {dict.footer.subscribe}
                </button>
              </form>
            )}
          </div>
        </div>

        <p className="mt-14 max-w-3xl text-xs leading-relaxed text-petrol-400">{dict.footer.disclaimer}</p>

        <div className="mt-8 flex flex-col items-start justify-between gap-4 border-t border-petrol-800 pt-8 text-xs text-petrol-400 sm:flex-row sm:items-center">
          <p>© {year} Equatorial Gateway Advisory. {dict.footer.rights}</p>
          <div className="flex gap-6">
            <span className="transition-colors hover:text-petrol-200">{dict.footer.privacy}</span>
            <span className="transition-colors hover:text-petrol-200">{dict.footer.terms}</span>
            <span className="transition-colors hover:text-petrol-200">{dict.footer.confidentiality}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
