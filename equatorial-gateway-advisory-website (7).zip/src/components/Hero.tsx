"use client";

import Link from "next/link";
import Image from "next/image";
import { motion, useScroll, useTransform, useReducedMotion } from "framer-motion";
import { useRef } from "react";
import { CompassMark } from "./Brand";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

export default function Hero({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "22%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const href = (p: string) => `/${locale}${p ? `/${p}` : ""}`;

  const ease = [0.16, 1, 0.3, 1] as const;

  return (
    <section ref={ref} className="relative flex min-h-[100svh] items-center overflow-hidden bg-petrol-950">
      <motion.div style={{ y }} className="absolute inset-0">
        <Image
          src="/images/hero.jpg"
          alt="Aerial view of a Central African port meeting equatorial rainforest at golden hour"
          fill
          priority
          sizes="100vw"
          className="kenburns object-cover"
        />
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-r from-petrol-950 via-petrol-950/80 to-petrol-950/20" />
      <div className="absolute inset-0 bg-gradient-to-t from-petrol-950 via-transparent to-petrol-950/40" />

      <CompassMark className="compass-spin pointer-events-none absolute -right-24 top-1/2 hidden h-[560px] w-[560px] -translate-y-1/2 text-white/[0.06] lg:block" />

      <motion.div style={{ opacity }} className="relative mx-auto w-full max-w-[1400px] px-5 pt-28 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease }}
          className="mb-6 flex items-center gap-3"
        >
          <span className="h-px w-10 bg-ember-500" />
          <span className="eyebrow text-ember-300">{dict.hero.eyebrow}</span>
        </motion.div>

        <h1 className="max-w-4xl font-display text-[2.6rem] font-extrabold leading-[1.02] tracking-tightest text-white sm:text-6xl lg:text-7xl xl:text-[5.4rem]">
          <motion.span
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.1, ease }}
            className="block"
          >
            {dict.hero.title1}
          </motion.span>
          <motion.span
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25, ease }}
            className="block text-gradient"
          >
            {dict.hero.title2}
          </motion.span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.4, ease }}
          className="mt-7 max-w-xl text-base leading-relaxed text-petrol-100/90 sm:text-lg"
        >
          {dict.hero.subtitle}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.55, ease }}
          className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center"
        >
          <Link
            href={href("contact")}
            className="group inline-flex items-center justify-center gap-2 rounded-full bg-ember-500 px-7 py-4 text-sm font-semibold text-white transition-all hover:bg-ember-400 hover:shadow-[0_16px_40px_-12px_rgba(200,83,31,0.6)]"
          >
            {dict.hero.ctaPrimary}
            <svg width="16" height="16" viewBox="0 0 24 24" className="transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5 12h14M13 6l6 6-6 6" />
            </svg>
          </Link>
          <Link
            href={href("opportunities")}
            className="inline-flex items-center justify-center gap-2 rounded-full border border-white/25 px-7 py-4 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:border-white hover:bg-white/5"
          >
            {dict.hero.ctaSecondary}
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-14 flex flex-wrap gap-x-8 gap-y-3"
        >
          {dict.hero.badges.map((b) => (
            <span key={b} className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-petrol-200">
              <span className="h-1.5 w-1.5 rounded-full bg-ember-400" />
              {b}
            </span>
          ))}
        </motion.div>
      </motion.div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-petrol-300">
        <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }} className="flex flex-col items-center gap-2">
          <span className="text-[10px] uppercase tracking-[0.2em]">{dict.hero.scroll}</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 5v14M6 13l6 6 6-6" />
          </svg>
        </motion.div>
      </div>
    </section>
  );
}
