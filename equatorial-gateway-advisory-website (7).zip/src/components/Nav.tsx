"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Wordmark } from "./Brand";
import { navItems } from "@/lib/routes";
import { locales, localeNames, localeFlags, type Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

export default function Nav({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    document.documentElement.lang = locale;
    setDark(document.documentElement.classList.contains("dark"));
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    setLangOpen(false);
  }, [pathname]);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("ega-theme", next ? "dark" : "light");
    } catch {}
  };

  // path without locale prefix, e.g. /en/about -> /about
  const sub = pathname.replace(/^\/(en|fr|de)/, "") || "/";
  const localizedPath = (l: Locale) => `/${l}${sub === "/" ? "" : sub}`;
  const href = (p: string) => `/${locale}${p ? `/${p}` : ""}`;
  const isActive = (p: string) => (p ? sub === `/${p}` || sub.startsWith(`/${p}`) : sub === "/");

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled ? "glass border-b py-2.5 shadow-[0_8px_40px_-24px_rgba(0,0,0,0.45)]" : "py-4"
        }`}
      >
        <nav className="mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-5 lg:px-10">
          <Link href={href("")} aria-label="EGA home" className="shrink-0">
            <Wordmark />
          </Link>

          <div className="hidden items-center gap-7 xl:flex">
            {navItems.map((item) => (
              <Link
                key={item.key}
                href={href(item.path)}
                className={`link-underline text-[13px] font-medium tracking-wide transition-colors ${
                  isActive(item.path) ? "text-ember-500" : "text-slatey-600 hover:text-petrol-800 dark:text-petrol-100 dark:hover:text-white"
                }`}
              >
                {dict.nav[item.key]}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* language */}
            <div className="relative">
              <button
                onClick={() => setLangOpen((v) => !v)}
                aria-label={dict.nav.language}
                aria-expanded={langOpen}
                className="flex items-center gap-1.5 rounded-full border px-3 py-2 text-xs font-semibold text-slatey-600 transition-colors hover:border-ember-400 hover:text-ember-500 dark:text-petrol-100"
              >
                <span>{localeFlags[locale]}</span>
                <span className="hidden sm:inline uppercase">{locale}</span>
                <svg width="10" height="10" viewBox="0 0 10 10" className={`transition-transform ${langOpen ? "rotate-180" : ""}`}>
                  <path d="M1 3l4 4 4-4" stroke="currentColor" strokeWidth="1.4" fill="none" />
                </svg>
              </button>
              <AnimatePresence>
                {langOpen && (
                  <motion.ul
                    initial={{ opacity: 0, y: 8, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.97 }}
                    transition={{ duration: 0.18 }}
                    className="glass absolute right-0 mt-2 w-44 overflow-hidden rounded-2xl border p-1.5 shadow-xl"
                  >
                    {locales.map((l) => (
                      <li key={l}>
                        <Link
                          href={localizedPath(l)}
                          className={`flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                            l === locale ? "bg-ember-500/10 text-ember-500" : "hover:bg-petrol-500/10"
                          }`}
                        >
                          <span>{localeFlags[l]}</span>
                          <span className="font-medium">{localeNames[l]}</span>
                        </Link>
                      </li>
                    ))}
                  </motion.ul>
                )}
              </AnimatePresence>
            </div>

            {/* theme */}
            <button
              onClick={toggleTheme}
              aria-label={dict.nav.theme}
              className="flex h-9 w-9 items-center justify-center rounded-full border text-slatey-600 transition-colors hover:border-ember-400 hover:text-ember-500 dark:text-petrol-100"
            >
              {dark ? (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <circle cx="12" cy="12" r="4" />
                  <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
                </svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
                </svg>
              )}
            </button>

            <Link
              href={href("contact")}
              className="hidden rounded-full bg-petrol-800 px-5 py-2.5 text-[13px] font-semibold text-white transition-all hover:bg-ember-500 dark:bg-white dark:text-petrol-900 dark:hover:bg-ember-500 dark:hover:text-white lg:inline-block"
            >
              {dict.nav.cta}
            </Link>

            <button
              onClick={() => setOpen(true)}
              aria-label={dict.nav.menu}
              className="flex h-9 w-9 items-center justify-center rounded-full border text-slatey-700 dark:text-petrol-100 xl:hidden"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M3 6h18M3 12h18M3 18h18" />
              </svg>
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] xl:hidden"
          >
            <div className="absolute inset-0 bg-petrol-950/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col bg-[var(--bg)] p-6 shadow-2xl"
            >
              <div className="mb-8 flex items-center justify-between">
                <Wordmark />
                <button
                  onClick={() => setOpen(false)}
                  aria-label={dict.nav.close}
                  className="flex h-9 w-9 items-center justify-center rounded-full border"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M6 6l12 12M18 6L6 18" />
                  </svg>
                </button>
              </div>
              <nav className="flex flex-col">
                <Link href={href("")} className="border-b py-3.5 font-display text-lg font-semibold">
                  {dict.nav.home}
                </Link>
                {navItems.map((item) => (
                  <Link key={item.key} href={href(item.path)} className="border-b py-3.5 font-display text-lg font-semibold">
                    {dict.nav[item.key]}
                  </Link>
                ))}
                <Link href={href("portal")} className="border-b py-3.5 font-display text-lg font-semibold text-ember-500">
                  {dict.nav.portal}
                </Link>
              </nav>
              <Link
                href={href("contact")}
                className="mt-8 rounded-full bg-ember-500 px-5 py-3.5 text-center font-semibold text-white"
              >
                {dict.nav.cta}
              </Link>
              <div className="mt-auto flex items-center gap-2 pt-8">
                {locales.map((l) => (
                  <Link
                    key={l}
                    href={localizedPath(l)}
                    className={`flex-1 rounded-xl border py-2.5 text-center text-sm font-semibold ${
                      l === locale ? "border-ember-400 text-ember-500" : "text-slatey-600 dark:text-petrol-100"
                    }`}
                  >
                    {localeFlags[l]} {l.toUpperCase()}
                  </Link>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
