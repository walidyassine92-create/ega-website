"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Reveal } from "./Motion";
import { countries, t } from "@/lib/data";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

export default function Portal({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const p = dict.portal;
  const [submitted, setSubmitted] = useState(false);

  const field = "w-full rounded-xl border border-petrol-700 bg-petrol-900/50 px-4 py-3 text-sm text-white placeholder:text-petrol-400 focus:border-ember-400 focus:outline-none focus:ring-2 focus:ring-ember-500/20";
  const label = "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-petrol-300";

  return (
    <section className="relative overflow-hidden bg-petrol-950 pb-28 pt-36 text-white lg:pt-44">
      <div className="grid-veil pointer-events-none absolute inset-0 opacity-15" />
      <div className="pointer-events-none absolute -right-32 top-0 h-[420px] w-[420px] rounded-full bg-ember-500/15 blur-[130px]" />
      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
        <Reveal>
          <div className="mb-5 flex items-center gap-3">
            <span className="h-px w-9 bg-ember-500" />
            <span className="eyebrow text-ember-300">{p.eyebrow}</span>
          </div>
        </Reveal>
        <Reveal delay={0.05}>
          <h1 className="max-w-3xl font-display text-4xl font-extrabold leading-[1.04] tracking-tightest sm:text-5xl lg:text-6xl">{p.title}</h1>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-petrol-200 sm:text-lg">{p.lead}</p>
        </Reveal>

        <div className="mt-16 grid gap-10 lg:grid-cols-[1.2fr_1fr]">
          {/* Dashboard preview */}
          <Reveal>
            <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-7 backdrop-blur-sm lg:p-9">
              <div className="mb-6 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-ember-500/20 text-ember-300">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3v18h18M7 14l4-4 4 4 5-6" /></svg>
                  </span>
                  <p className="font-display text-sm font-bold">{p.features[1].title}</p>
                </div>
                <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-emerald-300">Live</span>
              </div>
              <div className="space-y-4">
                {countries.slice(0, 6).map((c, i) => {
                  const w = [78, 64, 52, 88, 46, 71][i];
                  return (
                    <div key={c.id}>
                      <div className="mb-1.5 flex items-center justify-between text-xs">
                        <span className="text-petrol-200">{c.flag} {t(c.name, locale)}</span>
                        <span className="font-semibold text-white">{c.gdp}</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-white/10">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${w}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.1, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                          className="h-full rounded-full bg-gradient-to-r from-ember-600 to-ember-400"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-6 grid grid-cols-3 gap-3 border-t border-white/10 pt-6 text-center">
                <div><p className="font-display text-2xl font-bold text-white">9</p><p className="text-[10px] uppercase tracking-wider text-petrol-300">Active deals</p></div>
                <div><p className="font-display text-2xl font-bold text-ember-400">$2.3B</p><p className="text-[10px] uppercase tracking-wider text-petrol-300">In pipeline</p></div>
                <div><p className="font-display text-2xl font-bold text-white">8</p><p className="text-[10px] uppercase tracking-wider text-petrol-300">Markets</p></div>
              </div>
            </div>
          </Reveal>

          {/* Access form */}
          <Reveal delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-7 backdrop-blur-sm lg:p-9">
              <div className="mb-5 flex items-center gap-2 text-ember-300">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
                <h2 className="font-display text-lg font-bold text-white">{p.formTitle}</h2>
              </div>
              {submitted ? (
                <div className="rounded-2xl border border-ember-400/30 bg-ember-500/10 p-6 text-sm leading-relaxed text-ember-100">
                  {p.demo}
                </div>
              ) : (
                <>
                  <p className="mb-6 text-sm leading-relaxed text-petrol-200">{p.formLead}</p>
                  <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="space-y-4">
                    <div>
                      <label className={label} htmlFor="pt-id">{p.accessId}</label>
                      <input id="pt-id" required className={field} />
                    </div>
                    <div>
                      <label className={label} htmlFor="pt-email">{p.email}</label>
                      <input id="pt-email" type="email" required className={field} />
                    </div>
                    <button className="w-full rounded-full bg-ember-500 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-ember-400">{p.submit}</button>
                  </form>
                </>
              )}
              <p className="mt-5 text-xs leading-relaxed text-petrol-400">{p.note}</p>
            </div>
          </Reveal>
        </div>

        {/* Features */}
        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {p.features.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.06}>
              <div className="h-full rounded-2xl border border-white/10 bg-white/[0.02] p-7">
                <p className="font-display text-lg font-bold text-white">{f.title}</p>
                <p className="mt-2 text-sm leading-relaxed text-petrol-200">{f.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
