"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { motion, useScroll, useTransform, useReducedMotion } from "framer-motion";
import { useRef } from "react";
import { Reveal, Stagger, StaggerItem, Counter } from "./Motion";
import { sectors, countries, opportunities, processSteps, insights, t, type Opportunity } from "@/lib/data";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

/* ========================================================
   SECTION HEADING
   ======================================================== */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  center = false,
  light = false,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  center?: boolean;
  light?: boolean;
}) {
  return (
    <div className={`${center ? "mx-auto text-center" : ""} max-w-2xl`}>
      <Reveal>
        <div className={`mb-4 flex items-center gap-3 ${center ? "justify-center" : ""}`}>
          <span className="h-px w-9 bg-ember-500" />
          <span className={`eyebrow ${light ? "text-ember-300" : "text-ember-600 dark:text-ember-400"}`}>{eyebrow}</span>
        </div>
      </Reveal>
      <Reveal delay={0.05}>
        <h2 className={`font-display text-3xl font-extrabold tracking-tightest sm:text-4xl lg:text-5xl ${light ? "text-white" : "text-petrol-900 dark:text-white"}`}>
          {title}
        </h2>
      </Reveal>
      {subtitle && (
        <Reveal delay={0.1}>
          <p className={`mt-5 text-base leading-relaxed sm:text-lg ${light ? "text-petrol-200" : "text-slatey-600 dark:text-petrol-200"}`}>{subtitle}</p>
        </Reveal>
      )}
    </div>
  );
}

/* ========================================================
   PAGE HERO — with optional background image
   ======================================================== */
export function PageHero({ eyebrow, title, lead, image }: { eyebrow: string; title: string; lead: string; image?: string }) {
  return (
    <section className="relative overflow-hidden bg-petrol-950 pb-20 pt-36 text-white lg:pb-28 lg:pt-44">
      {image && (
        <>
          <div className="absolute inset-0">
            <Image src={image} alt="" fill sizes="100vw" className="object-cover opacity-30" priority />
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-petrol-950 via-petrol-950/90 to-petrol-950/60" />
        </>
      )}
      <div className="grid-veil pointer-events-none absolute inset-0 opacity-20" />
      <div className="pointer-events-none absolute -right-32 -top-20 h-[420px] w-[420px] rounded-full bg-ember-500/15 blur-[130px]" />
      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
        <Reveal>
          <div className="mb-5 flex items-center gap-3">
            <span className="h-px w-9 bg-ember-500" />
            <span className="eyebrow text-ember-300">{eyebrow}</span>
          </div>
        </Reveal>
        <Reveal delay={0.05}>
          <h1 className="max-w-4xl font-display text-4xl font-extrabold leading-[1.04] tracking-tightest sm:text-5xl lg:text-6xl xl:text-7xl">{title}</h1>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-7 max-w-2xl text-base leading-relaxed text-petrol-200 sm:text-lg">{lead}</p>
        </Reveal>
      </div>
    </section>
  );
}

/* ========================================================
   MARQUEE
   ======================================================== */
export function Marquee({ items }: { items: readonly string[] }) {
  const row = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-[var(--line)] bg-[var(--bg-soft)] py-6">
      <div className="marquee-track flex w-max gap-12 whitespace-nowrap">
        {row.map((item, i) => (
          <span key={i} className="flex items-center gap-12 text-sm font-medium uppercase tracking-[0.2em] text-slatey-400 dark:text-petrol-300">
            {item}
            <span className="text-ember-500">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

/* ========================================================
   STATS BAND — with parallax background image
   ======================================================== */
export function StatsBand({ dict }: { dict: Dictionary }) {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["0%", "20%"]);

  return (
    <section ref={ref} className="relative overflow-hidden bg-petrol-900 py-20 text-white lg:py-28">
      {/* Background image with parallax */}
      <motion.div style={{ y: bgY }} className="absolute inset-0 -top-[20%] -bottom-[20%]">
        <Image src="/images/infrastructure.jpg" alt="" fill sizes="100vw" className="object-cover opacity-[0.12]" />
      </motion.div>
      <div className="grid-veil pointer-events-none absolute inset-0 opacity-[0.15]" />
      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
        <SectionHeading eyebrow={dict.stats.eyebrow} title={dict.stats.title} light />
        <Stagger className="mt-14 grid gap-px overflow-hidden rounded-3xl border border-white/10 bg-white/5 sm:grid-cols-2 lg:grid-cols-4">
          {dict.stats.items.map((s, i) => (
            <StaggerItem key={i} className="bg-petrol-950/40 p-8 backdrop-blur-sm">
              <p className="font-display text-4xl font-extrabold tracking-tightest text-white lg:text-5xl">
                <Counter value={s.value} prefix={(s as { prefix?: string }).prefix ?? ""} suffix={s.suffix ?? ""} decimals={s.value % 1 !== 0 ? 1 : 0} />
              </p>
              <p className="mt-3 text-sm leading-relaxed text-petrol-200">{s.label}</p>
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}

/* ========================================================
   SECTORS GRID — photo-rich cards with hover image reveal
   ======================================================== */
export function SectorsGrid({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  return (
    <Stagger className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {sectors.map((s) => (
        <StaggerItem key={s.id}>
          <Link
            href={`/${locale}/sectors#${s.id}`}
            className="lift group relative flex h-full flex-col overflow-hidden rounded-2xl border bg-[var(--card)] hover:border-ember-400"
          >
            {/* Sector photo — visible on hover or for sectors with images */}
            {s.image && (
              <div className="relative h-40 overflow-hidden">
                <Image
                  src={s.image}
                  alt={t(s.name, locale)}
                  fill
                  sizes="(max-width:640px) 100vw, (max-width:1024px) 50vw, 33vw"
                  className="object-cover transition-transform duration-700 ease-[var(--ease-luxe)] group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[var(--card)] to-transparent" />
                <span className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-xl bg-white/90 text-xl shadow-lg backdrop-blur-sm dark:bg-petrol-900/90">{s.icon}</span>
              </div>
            )}
            <div className={`flex flex-1 flex-col p-6 ${!s.image ? "pt-7" : ""}`}>
              {!s.image && <span className="mb-4 text-3xl">{s.icon}</span>}
              <h3 className="font-display text-lg font-bold text-petrol-900 dark:text-white">{t(s.name, locale)}</h3>
              <p className="mt-2.5 flex-1 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{t(s.blurb, locale)}</p>
              <span className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-ember-500 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                {dict.common.learnMore}
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </span>
            </div>
          </Link>
        </StaggerItem>
      ))}
    </Stagger>
  );
}

/* ========================================================
   SECTORS FEATURED — alternating large layout for sectors page
   ======================================================== */
export function SectorsFeatured({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const featured = sectors.filter((s) => s.image);
  return (
    <div className="space-y-8">
      {featured.map((s, i) => (
        <Reveal key={s.id} delay={0.05}>
          <div
            id={s.id}
            className={`lift group grid scroll-mt-28 items-center gap-6 overflow-hidden rounded-3xl border bg-[var(--card)] hover:border-ember-400 lg:grid-cols-2 ${i % 2 !== 0 ? "lg:direction-rtl" : ""}`}
          >
            <div className={`relative aspect-[16/10] overflow-hidden ${i % 2 !== 0 ? "lg:order-2" : ""}`}>
              <Image
                src={s.image!}
                alt={t(s.name, locale)}
                fill
                sizes="(max-width:1024px) 100vw, 50vw"
                className="object-cover transition-transform duration-700 ease-[var(--ease-luxe)] group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[var(--card)]/30 to-transparent" />
            </div>
            <div className={`p-8 lg:p-10 ${i % 2 !== 0 ? "lg:order-1" : ""}`}>
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ember-500/10 text-2xl">{s.icon}</span>
              <h2 className="mt-5 font-display text-2xl font-bold tracking-tightest text-petrol-900 dark:text-white lg:text-3xl">{t(s.name, locale)}</h2>
              <p className="mt-4 text-base leading-relaxed text-slatey-600 dark:text-petrol-200">{t(s.blurb, locale)}</p>
              <Link
                href={`/${locale}/opportunities`}
                className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-ember-500 transition-colors hover:text-ember-400"
              >
                {dict.common.learnMore}
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </Link>
            </div>
          </div>
        </Reveal>
      ))}
      {/* Remaining sectors without dedicated images — compact grid */}
      {sectors.filter((s) => !s.image).length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {sectors.filter((s) => !s.image).map((s) => (
            <Reveal key={s.id}>
              <div id={s.id} className="lift flex scroll-mt-28 flex-col rounded-2xl border bg-[var(--card)] p-6 hover:border-ember-400">
                <span className="text-2xl">{s.icon}</span>
                <h3 className="mt-4 font-display text-lg font-bold text-petrol-900 dark:text-white">{t(s.name, locale)}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{t(s.blurb, locale)}</p>
              </div>
            </Reveal>
          ))}
        </div>
      )}
    </div>
  );
}

/* ========================================================
   COUNTRY EXPLORER — richer with animated progress bars
   ======================================================== */
export function CountryExplorer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const [active, setActive] = useState(countries[0].id);
  const country = countries.find((c) => c.id === active)!;
  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <Reveal>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-2">
          {countries.map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={`lift flex items-center gap-3 rounded-2xl border p-4 text-left transition-all ${
                active === c.id ? "border-ember-400 bg-ember-500/5 shadow-[0_4px_24px_-8px_rgba(200,83,31,0.25)]" : "bg-[var(--card)] hover:border-petrol-300"
              }`}
            >
              <span className="text-2xl">{c.flag}</span>
              <span className={`text-sm font-semibold ${active === c.id ? "text-ember-500" : "text-petrol-800 dark:text-white"}`}>{t(c.name, locale)}</span>
            </button>
          ))}
        </div>
        <p className="mt-4 text-xs text-slatey-500 dark:text-petrol-300">{dict.whySection.mapHint}</p>
      </Reveal>

      <motion.div
        key={country.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-3xl border bg-petrol-900 p-8 text-white lg:p-10"
      >
        <span className="pointer-events-none absolute -right-6 -top-8 text-[10rem] leading-none opacity-10">{country.flag}</span>
        {/* Subtle image background for the detail panel */}
        <div className="pointer-events-none absolute inset-0 opacity-[0.07]">
          <Image src="/images/hero.jpg" alt="" fill sizes="50vw" className="object-cover" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-4">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 text-3xl backdrop-blur-sm">{country.flag}</span>
            <div>
              <h3 className="font-display text-2xl font-bold">{t(country.name, locale)}</h3>
              <p className="text-sm text-petrol-300">{t(country.capital, locale)}</p>
            </div>
          </div>
          <p className="mt-6 font-serif-display text-xl italic text-ember-200">{t(country.tagline, locale)}</p>
          <p className="mt-4 text-sm leading-relaxed text-petrol-200">{t(country.highlights, locale)}</p>
          <div className="mt-8 flex gap-10 border-t border-white/10 pt-6">
            <div>
              <p className="font-display text-2xl font-bold">{country.gdp}</p>
              <p className="text-xs uppercase tracking-wider text-petrol-300">GDP</p>
            </div>
            <div>
              <p className="font-display text-2xl font-bold">{country.population}</p>
              <p className="text-xs uppercase tracking-wider text-petrol-300">Population</p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

/* ========================================================
   OPPORTUNITY CARD + GRID
   ======================================================== */
function OppCard({ op, locale, dict }: { op: Opportunity; locale: Locale; dict: Dictionary }) {
  const sector = sectors.find((s) => s.id === op.sectorId);
  const country = countries.find((c) => c.id === op.countryId);
  const L = dict.oppSection.labels;
  return (
    <div className="lift group flex h-full flex-col overflow-hidden rounded-3xl border bg-[var(--card)] hover:border-ember-400">
      {/* Sector image header on opp cards */}
      {sector?.image && (
        <div className="relative h-32 overflow-hidden">
          <Image
            src={sector.image}
            alt={t(sector.name, locale)}
            fill
            sizes="(max-width:768px) 100vw, (max-width:1024px) 50vw, 33vw"
            className="object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--card)] via-[var(--card)]/40 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
            <span className="flex items-center gap-2 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-petrol-800 shadow-sm backdrop-blur-sm dark:bg-petrol-900/90 dark:text-petrol-100">
              <span>{sector?.icon}</span>
              {sector && t(sector.name, locale)}
            </span>
            <span className="rounded-full bg-ember-500/90 px-3 py-1 text-[10px] font-semibold uppercase tracking-wide text-white shadow-sm backdrop-blur-sm">
              {t(op.status, locale)}
            </span>
          </div>
        </div>
      )}
      <div className="flex flex-1 flex-col p-6">
        {!sector?.image && (
          <div className="mb-4 flex items-center justify-between">
            <span className="flex items-center gap-2 text-sm font-medium text-slatey-500 dark:text-petrol-200">
              <span className="text-xl">{sector?.icon}</span>
              {sector && t(sector.name, locale)}
            </span>
            <span className="rounded-full bg-ember-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-ember-600 dark:text-ember-300">
              {t(op.status, locale)}
            </span>
          </div>
        )}
        <h3 className="font-display text-xl font-bold leading-snug text-petrol-900 dark:text-white">{t(op.title, locale)}</h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{t(op.summary, locale)}</p>
        <div className="mt-6 grid grid-cols-2 gap-4 border-t pt-5 text-sm">
          <div>
            <p className="text-[11px] uppercase tracking-wider text-slatey-400 dark:text-petrol-300">{L.investment}</p>
            <p className="font-display text-lg font-bold text-petrol-900 dark:text-white">{op.amount}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-wider text-slatey-400 dark:text-petrol-300">{L.roi}</p>
            <p className="font-display text-lg font-bold text-ember-500">{op.roi}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-wider text-slatey-400 dark:text-petrol-300">{L.country}</p>
            <p className="font-medium text-petrol-800 dark:text-petrol-100">{country?.flag} {country && t(country.name, locale)}</p>
          </div>
          <div className="flex items-end justify-end">
            <Link href={`/${locale}/contact`} className="inline-flex items-center gap-1.5 text-xs font-semibold text-ember-500 transition-colors hover:text-ember-400">
              {dict.oppSection.request}
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export function OpportunityGrid({ locale, dict, items }: { locale: Locale; dict: Dictionary; items?: Opportunity[] }) {
  const list = items ?? opportunities;
  return (
    <Stagger className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      {list.map((op) => (
        <StaggerItem key={op.id}>
          <OppCard op={op} locale={locale} dict={dict} />
        </StaggerItem>
      ))}
    </Stagger>
  );
}

export function OpportunityExplorer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const [filter, setFilter] = useState<string>("all");
  const usedSectors = sectors.filter((s) => opportunities.some((o) => o.sectorId === s.id));
  const list = filter === "all" ? opportunities : opportunities.filter((o) => o.sectorId === filter);
  return (
    <div>
      <div className="mb-10 flex flex-wrap gap-2.5">
        <button
          onClick={() => setFilter("all")}
          className={`rounded-full border px-4 py-2 text-xs font-semibold transition-all ${filter === "all" ? "border-ember-400 bg-ember-500 text-white" : "hover:border-ember-400"}`}
        >
          {dict.oppPage.filterAll}
        </button>
        {usedSectors.map((s) => (
          <button
            key={s.id}
            onClick={() => setFilter(s.id)}
            className={`rounded-full border px-4 py-2 text-xs font-semibold transition-all ${filter === s.id ? "border-ember-400 bg-ember-500 text-white" : "hover:border-ember-400"}`}
          >
            {s.icon} {t(s.name, locale)}
          </button>
        ))}
      </div>
      {list.length ? (
        <OpportunityGrid locale={locale} dict={dict} items={list} />
      ) : (
        <p className="py-16 text-center text-slatey-500">{dict.oppPage.empty}</p>
      )}
    </div>
  );
}

/* ========================================================
   PROCESS TIMELINE — enhanced with images + progress line
   ======================================================== */
const stepImages = [
  "/images/boardroom.jpg",
  "/images/mining.jpg",
  null,
  "/images/infrastructure.jpg",
  "/images/boardroom.jpg",
  null,
  "/images/logistics.jpg",
  "/images/digital.jpg",
];

export function ProcessTimeline({ locale }: { locale: Locale }) {
  return (
    <div className="relative">
      {/* Animated gradient line */}
      <div className="absolute left-[15px] top-2 bottom-2 w-px bg-gradient-to-b from-ember-500 via-petrol-400 to-transparent md:left-1/2" />
      <div className="space-y-3 md:space-y-0">
        {processSteps.map((step, i) => {
          const img = stepImages[i] ?? null;
          return (
            <Reveal key={step.n} delay={i * 0.04}>
              <div className={`relative flex gap-6 md:w-1/2 ${i % 2 === 0 ? "md:pr-12" : "md:ml-auto md:flex-row-reverse md:pl-12 md:text-right"}`}>
                <div
                  className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 border-ember-500 bg-[var(--bg)] text-[11px] font-bold text-ember-500 md:absolute md:top-6 md:-mr-4 md:translate-x-0"
                  style={i % 2 === 0 ? { right: "-16px" } : { left: "-16px" }}
                >
                  {step.n}
                </div>
                <div className="lift flex-1 overflow-hidden rounded-2xl border bg-[var(--card)] md:mb-8">
                  {/* Inline image for steps that have one */}
                  {img && (
                    <div className="relative h-28 overflow-hidden">
                      <Image src={img} alt={t(step.title, locale)} fill sizes="(max-width:768px) 100vw, 50vw" className="object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[var(--card)] to-transparent" />
                    </div>
                  )}
                  <div className="p-6">
                    <div className="flex items-center gap-3">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ember-500/10 font-display text-xs font-bold text-ember-500 md:hidden">{step.n}</span>
                      <h3 className="font-display text-lg font-bold text-petrol-900 dark:text-white">{t(step.title, locale)}</h3>
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{t(step.text, locale)}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}

/* ========================================================
   INSIGHTS GRID — enriched with category images
   ======================================================== */
const insightImages = [
  "/images/boardroom.jpg",
  "/images/mining.jpg",
  "/images/infrastructure.jpg",
  "/images/logistics.jpg",
];

export function InsightsGrid({ locale, dict, limit }: { locale: Locale; dict: Dictionary; limit?: number }) {
  const list = limit ? insights.slice(0, limit) : insights;
  return (
    <Stagger className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {list.map((article, i) => (
        <StaggerItem key={article.id}>
          <Link href={`/${locale}/insights/${article.id}`} className="lift group flex h-full flex-col overflow-hidden rounded-3xl border bg-[var(--card)] hover:border-ember-400">
            {/* Insight hero image */}
            <div className="relative h-40 overflow-hidden">
              <Image
                src={insightImages[i % insightImages.length]}
                alt={t(article.title, locale)}
                fill
                sizes="(max-width:768px) 100vw, (max-width:1024px) 50vw, 33vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[var(--card)] via-[var(--card)]/20 to-transparent" />
              <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs">
                <span className="rounded-full bg-white/90 px-3 py-1 font-semibold uppercase tracking-wide text-petrol-600 shadow-sm backdrop-blur-sm dark:bg-petrol-900/90 dark:text-petrol-200">{t(article.category, locale)}</span>
                <span className="rounded-full bg-black/40 px-3 py-1 font-medium text-white backdrop-blur-sm">{article.readMin} {dict.insightsSection.min}</span>
              </div>
            </div>
            <div className="flex flex-1 flex-col p-6">
              <h3 className="font-display text-lg font-bold leading-snug text-petrol-900 dark:text-white">{t(article.title, locale)}</h3>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-slatey-600 dark:text-petrol-200">{t(article.excerpt, locale)}</p>
              <span className="mt-6 inline-flex items-center gap-1.5 text-xs font-semibold text-ember-500">
                {dict.insightsSection.read}
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="transition-transform group-hover:translate-x-1"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
              </span>
            </div>
          </Link>
        </StaggerItem>
      ))}
    </Stagger>
  );
}

/* ========================================================
   CTA SECTION — with cinematic background
   ======================================================== */
export function CTASection({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const href = (p: string) => `/${locale}/${p}`;
  return (
    <section className="relative overflow-hidden bg-petrol-950 py-24 text-white lg:py-32">
      {/* Background image */}
      <div className="absolute inset-0">
        <Image src="/images/hero.jpg" alt="" fill sizes="100vw" className="object-cover opacity-[0.08]" />
      </div>
      <div className="grid-veil pointer-events-none absolute inset-0 opacity-20" />
      <div className="pointer-events-none absolute -left-20 top-1/2 h-[400px] w-[400px] -translate-y-1/2 rounded-full bg-ember-500/20 blur-[120px]" />
      <div className="pointer-events-none absolute -right-20 top-1/3 h-[300px] w-[300px] rounded-full bg-petrol-400/10 blur-[100px]" />
      <div className="relative mx-auto max-w-3xl px-5 text-center lg:px-10">
        <Reveal>
          <div className="mb-5 flex items-center justify-center gap-3">
            <span className="h-px w-9 bg-ember-500" />
            <span className="eyebrow text-ember-300">{dict.cta.eyebrow}</span>
            <span className="h-px w-9 bg-ember-500" />
          </div>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="font-display text-4xl font-extrabold tracking-tightest sm:text-5xl lg:text-6xl">{dict.cta.title}</h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-petrol-200 sm:text-lg">{dict.cta.subtitle}</p>
        </Reveal>
        <Reveal delay={0.15}>
          <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
            <Link href={href("contact")} className="rounded-full bg-ember-500 px-8 py-4 text-sm font-semibold text-white transition-all hover:bg-ember-400 hover:shadow-[0_16px_40px_-12px_rgba(200,83,31,0.6)]">
              {dict.cta.primary}
            </Link>
            <Link href={href("portal")} className="rounded-full border border-white/25 px-8 py-4 text-sm font-semibold text-white transition-all hover:border-white hover:bg-white/5">
              {dict.cta.secondary}
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
