import { pgTable, serial, text, varchar, timestamp } from "drizzle-orm/pg-core";

// Inbound advisory enquiries from the contact form.
export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  company: varchar("company", { length: 200 }),
  country: varchar("country", { length: 120 }),
  phone: varchar("phone", { length: 60 }),
  email: varchar("email", { length: 200 }).notNull(),
  sector: varchar("sector", { length: 120 }),
  budget: varchar("budget", { length: 120 }),
  message: text("message").notNull(),
  locale: varchar("locale", { length: 8 }).default("en"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// Private appointment / investment mission booking requests.
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  organisation: varchar("organisation", { length: 200 }),
  preferredDate: varchar("preferred_date", { length: 40 }),
  topic: varchar("topic", { length: 200 }),
  notes: text("notes"),
  locale: varchar("locale", { length: 8 }).default("en"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
