import type { Metadata } from "next";
import { isLocale, type Locale } from "@/i18n/config";
import { getDictionary, type Dictionary } from "@/i18n/dictionaries";

type MetaKey = keyof Dictionary["meta"];

export function pageMeta(locale: string, key: MetaKey, path: string): Metadata {
  const l = (isLocale(locale) ? locale : "en") as Locale;
  const dict = getDictionary(l);
  const m = dict.meta[key];
  const url = `/${l}${path ? `/${path}` : ""}`;
  return {
    title: m.title,
    description: m.description,
    alternates: {
      canonical: url,
      languages: {
        en: `/en${path ? `/${path}` : ""}`,
        fr: `/fr${path ? `/${path}` : ""}`,
        de: `/de${path ? `/${path}` : ""}`,
      },
    },
    openGraph: { title: m.title, description: m.description, url },
  };
}

export function resolveLocale(locale: string): Locale {
  return (isLocale(locale) ? locale : "en") as Locale;
}
