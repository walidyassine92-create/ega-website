import type { Dictionary } from "@/i18n/dictionaries";

export const navItems = [
  { key: "about", path: "about" },
  { key: "services", path: "services" },
  { key: "opportunities", path: "opportunities" },
  { key: "why", path: "why-central-africa" },
  { key: "sectors", path: "sectors" },
  { key: "process", path: "process" },
  { key: "insights", path: "insights" },
] as const;

export type NavKey = (typeof navItems)[number]["key"];

export function navLabel(dict: Dictionary, key: NavKey): string {
  return dict.nav[key];
}

export const allRoutes = ["", "about", "services", "opportunities", "why-central-africa", "sectors", "process", "insights", "contact", "portal"];
