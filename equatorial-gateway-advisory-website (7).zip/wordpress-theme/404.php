<?php
/**
 * 404 Page
 * @package ega
 */
get_header();
?>

<div class="ega-404">
    <svg viewBox="0 0 120 120" style="width:64px;height:64px;color:rgba(255,255,255,0.7);" fill="none">
        <g><path d="M60 10 L67 53 L60 60 L53 53 Z" fill="currentColor"/><path d="M60 110 L53 67 L60 60 L67 67 Z" fill="currentColor" opacity="0.7"/></g>
        <path d="M22 92 L48 66 L62 78 L92 40" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M78 40 L92 40 L92 54" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <p class="code" style="margin-top:32px;">404</p>
    <p style="margin-top:12px;max-width:320px;color:var(--petrol-200);"><?php esc_html_e('This page has drifted off the map. Let us guide you back.', 'ega'); ?></p>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="ega-btn-ember" style="margin-top:32px;"><?php esc_html_e('Back to home', 'ega'); ?></a>
</div>

<?php get_footer(); ?>
