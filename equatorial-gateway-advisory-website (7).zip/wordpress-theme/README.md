# EGA — Equatorial Gateway Advisory WordPress Theme

An ultra-premium, production-ready WordPress theme for **Equatorial Gateway Advisory**, a strategic investment advisory firm connecting global capital with Central African opportunities.

---

## 🚀 Installation

### 1. Upload Theme
1. Zip the entire `wordpress-theme/` directory (rename it to `ega/` first).
2. Go to **WordPress Admin → Appearance → Themes → Add New → Upload Theme**.
3. Upload the zip and activate.

### 2. Set Up Pages
Create the following WordPress pages, assigning the matching **Page Template**:

| Page Title           | Slug                  | Template              |
|---------------------|-----------------------|-----------------------|
| Home                | `home` (set as front) | EGA Home              |
| About               | `about`               | About                 |
| Services            | `services`            | Services              |
| Opportunities       | `opportunities`       | *(uses CPT archive)*  |
| Why Central Africa  | `why-central-africa`  | Why Central Africa    |
| Sectors             | `sectors`             | Sectors               |
| Process             | `process`             | Process               |
| Insights            | `insights`            | *(uses CPT archive)*  |
| Contact             | `contact`             | Contact               |
| Investor Portal     | `portal`              | Investor Portal       |

Set your front page to the **Home** page under **Settings → Reading → "A static page"**.

### 3. Configure Permalinks
Go to **Settings → Permalinks** and select **Post name** (`/%postname%/`).

### 4. Add Content

**Opportunities:**
- Go to **Opportunities → Add New**
- Set Title, Excerpt, and Sectors/Countries via the taxonomies
- Fill in Investment Amount, Target ROI, and Status in the sidebar

**Insights:**
- Go to **Insights → Add New**
- Assign categories and set read time in the sidebar

### 5. Multilingual Setup (Polylang recommended)
1. Install and activate **Polylang** (free) or **WPML**
2. Add languages: English, French, German
3. The theme auto-registers translatable strings via `pll_register_string()`
4. Translate each page and its content
5. All `__()` strings can be translated via Polylang's string translation panel

### 6. Customizer
- **Appearance → Customize → EGA Contact Details** — set email, office locations, engagement hours

---

## 📁 Theme Structure

```
ega/
├── style.css                    # Theme metadata
├── functions.php                # CPTs, AJAX, SEO, i18n, enqueues
├── header.php                   # Navigation, language switcher, dark mode
├── footer.php                   # Footer with newsletter
├── front-page.php               # Home page (all sections)
├── page.php                     # Default page
├── page-about.php               # About template
├── page-services.php            # Services template
├── page-sectors.php             # Sectors template
├── page-why-central-africa.php  # Why Central Africa template
├── page-process.php             # Process template
├── page-contact.php             # Contact + Appointment forms
├── page-portal.php              # Investor Portal
├── index.php                    # Blog fallback
├── 404.php                      # 404 page
├── archive-ega_opportunity.php  # Opportunities archive + filter
├── archive-ega_insight.php      # Insights archive
├── single-ega_insight.php       # Insight article
├── template-parts/
│   ├── section-heading.php
│   ├── page-hero.php
│   ├── cta-section.php
│   ├── opp-card.php
│   └── insight-card.php
├── inc/
│   └── data.php                 # Static data (sectors, countries, process)
├── assets/
│   ├── css/theme.css            # Full design system
│   ├── js/theme.js              # Interactions, forms, dark mode
│   └── images/                  # Hero, boardroom, OG, etc.
└── languages/                   # Translation files
```

---

## ✅ Features

- **Dark mode** with localStorage persistence
- **Multilingual** — Polylang/WPML ready (EN, FR, DE)
- **Custom Post Types** — Opportunities, Insights, Enquiries, Appointments
- **Custom Taxonomies** — Sectors, Countries, Insight Categories
- **AJAX contact & appointment forms** with email notifications
- **SEO** — Schema.org structured data, Open Graph, meta tags
- **WCAG AA+** — semantic HTML, ARIA labels, keyboard navigation, reduced-motion
- **Animated counters, scroll reveal, marquee, Ken Burns hero**
- **Interactive country explorer** with GDP/Population data
- **Opportunity filtering** by sector
- **Investor Portal** with economic dashboard preview
- **Admin columns** for investment amounts and ROI
- **Customizer** for contact details
- **Admin enquiry/appointment storage** as private posts

---

## 🎨 Brand Tokens

| Token | Value |
|-------|-------|
| Deep Petroleum Blue | `#0a2230` |
| Burnt Orange/Ember  | `#c8531f` |
| Soft Grey            | `#f6f7f8` |
| Dark Slate           | `#262c33` |
| White                | `#ffffff` |

Fonts: **Inter** (body), **Manrope** (display), **Fraunces** (serif accents)

---

## 🔌 Recommended Plugins

| Plugin | Purpose |
|--------|---------|
| **Polylang** | Multilingual (FR, EN, DE) |
| **Yoast SEO** or **Rank Math** | Enhanced SEO |
| **WP Mail SMTP** | Reliable email delivery |
| **Wordfence** | Security |
| **WP Fastest Cache** or **LiteSpeed Cache** | Performance |
| **Smush** or **ShortPixel** | Image optimisation |

---

## 📧 Contact

contact@equatorialgatewayadvisory.com

---

*Built to the standards of McKinsey, BlackRock and the World Economic Forum — not a startup template.*
