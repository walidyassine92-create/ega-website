<?php
/**
 * Insights Archive
 * @package ega
 */
get_header();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Insights', 'ega'), 'title' => __('Research & intelligence.', 'ega'), 'lead' => __('Considered analysis on the economies, sectors and transactions shaping Central Africa.', 'ega')]); ?>

<section class="ega-section">
    <div class="ega-container">
        <?php if (have_posts()) : ?>
            <div class="ega-grid-3">
                <?php while (have_posts()) : the_post();
                    get_template_part('template-parts/insight-card');
                endwhile; ?>
            </div>
            <div style="margin-top:48px;text-align:center;">
                <?php the_posts_pagination(['prev_text' => '&larr;', 'next_text' => '&rarr;']); ?>
            </div>
        <?php else : ?>
            <p style="text-align:center;padding:64px 0;color:var(--slatey-500);"><?php esc_html_e('No insights yet.', 'ega'); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
