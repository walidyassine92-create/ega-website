<?php
/**
 * Opportunities Archive
 * @package ega
 */
get_header();
$sector_terms = get_terms(['taxonomy' => 'ega_sector', 'hide_empty' => true]);
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Opportunities', 'ega'), 'title' => __('Curated investment opportunities.', 'ega'), 'lead' => __('Institutionally screened opportunities across the region. Qualified investors receive full data rooms through the secure portal.', 'ega')]); ?>

<section class="ega-section">
    <div class="ega-container">
        <?php if (!is_wp_error($sector_terms) && !empty($sector_terms)) : ?>
            <div style="margin-bottom:40px;display:flex;flex-wrap:wrap;gap:10px;">
                <button class="ega-filter-btn ega-opp-filter active" data-sector="all"><?php esc_html_e('All sectors', 'ega'); ?></button>
                <?php foreach ($sector_terms as $term) : ?>
                    <button class="ega-filter-btn ega-opp-filter" data-sector="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (have_posts()) : ?>
            <div class="ega-grid-3">
                <?php while (have_posts()) : the_post();
                    $sector_t = get_the_terms(get_the_ID(), 'ega_sector');
                    $sector_slug = ($sector_t && !is_wp_error($sector_t)) ? $sector_t[0]->slug : '';
                ?>
                    <div class="ega-opp-item" data-sector="<?php echo esc_attr($sector_slug); ?>">
                        <?php get_template_part('template-parts/opp-card'); ?>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else : ?>
            <p style="text-align:center;padding:64px 0;color:var(--slatey-500);"><?php esc_html_e('No opportunities match this filter.', 'ega'); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
