/**
 * EGA — Equatorial Gateway Advisory
 * Premium Theme JavaScript
 */
(function () {
  'use strict';

  /* ---------- HEADER SCROLL ---------- */
  const header = document.querySelector('.ega-header');
  if (header) {
    const check = () => header.classList.toggle('scrolled', window.scrollY > 24);
    check();
    window.addEventListener('scroll', check, { passive: true });
  }

  /* ---------- DARK MODE ---------- */
  const html = document.documentElement;
  const themeBtn = document.getElementById('ega-theme-toggle');
  function setDark(d) {
    document.body.classList.toggle('dark-mode', d);
    try { localStorage.setItem('ega-theme', d ? 'dark' : 'light'); } catch (e) {}
    if (themeBtn) themeBtn.setAttribute('aria-label', d ? 'Switch to light mode' : 'Switch to dark mode');
  }
  // Initialise
  try {
    var saved = localStorage.getItem('ega-theme');
    setDark(saved ? saved === 'dark' : true);
  } catch (e) { setDark(true); }
  if (themeBtn) themeBtn.addEventListener('click', function () {
    setDark(!document.body.classList.contains('dark-mode'));
  });

  /* ---------- LANGUAGE DROPDOWN ---------- */
  const langBtn = document.getElementById('ega-lang-toggle');
  const langDrop = document.getElementById('ega-lang-dropdown');
  if (langBtn && langDrop) {
    langBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      langDrop.classList.toggle('open');
    });
    document.addEventListener('click', function () { langDrop.classList.remove('open'); });
  }

  /* ---------- MOBILE MENU ---------- */
  const menuOpen = document.getElementById('ega-menu-open');
  const menuClose = document.getElementById('ega-menu-close');
  const overlay = document.getElementById('ega-mobile-overlay');
  const mobileBg = overlay ? overlay.querySelector('.ega-mobile-bg') : null;
  function openMenu() { if (overlay) overlay.classList.add('open'); document.body.style.overflow = 'hidden'; }
  function closeMenu() { if (overlay) overlay.classList.remove('open'); document.body.style.overflow = ''; }
  if (menuOpen) menuOpen.addEventListener('click', openMenu);
  if (menuClose) menuClose.addEventListener('click', closeMenu);
  if (mobileBg) mobileBg.addEventListener('click', closeMenu);

  /* ---------- SCROLL REVEAL ---------- */
  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      els.forEach(function (el) { el.classList.add('visible'); });
      return;
    }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var delay = entry.target.dataset.delay || 0;
          setTimeout(function () { entry.target.classList.add('visible'); }, delay * 1000);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '-60px' });
    els.forEach(function (el) { obs.observe(el); });
  }
  initReveal();

  /* ---------- COUNTER ANIMATION ---------- */
  function initCounters() {
    var counters = document.querySelectorAll('[data-counter]');
    if (!counters.length) return;
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        var target = parseFloat(el.dataset.counter);
        var prefix = el.dataset.prefix || '';
        var suffix = el.dataset.suffix || '';
        var decimals = parseInt(el.dataset.decimals || '0', 10);
        obs.unobserve(el);
        if (reduce) { el.textContent = prefix + target.toFixed(decimals) + suffix; return; }
        var start = performance.now();
        var duration = 1600;
        function tick(now) {
          var p = Math.min((now - start) / duration, 1);
          var eased = 1 - Math.pow(1 - p, 3);
          el.textContent = prefix + (target * eased).toFixed(decimals) + suffix;
          if (p < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.3 });
    counters.forEach(function (el) { obs.observe(el); });
  }
  initCounters();

  /* ---------- COUNTRY EXPLORER ---------- */
  function initCountryExplorer() {
    var buttons = document.querySelectorAll('.ega-country-btn');
    var details = document.querySelectorAll('.ega-country-panel');
    if (!buttons.length || !details.length) return;
    buttons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.dataset.country;
        buttons.forEach(function (b) { b.classList.toggle('active', b.dataset.country === id); });
        details.forEach(function (d) {
          d.style.display = d.dataset.country === id ? 'block' : 'none';
          if (d.dataset.country === id) {
            d.style.opacity = '0'; d.style.transform = 'translateY(20px)';
            requestAnimationFrame(function () {
              d.style.transition = 'opacity 0.5s cubic-bezier(0.16,1,0.3,1), transform 0.5s cubic-bezier(0.16,1,0.3,1)';
              d.style.opacity = '1'; d.style.transform = 'translateY(0)';
            });
          }
        });
      });
    });
    // Activate first
    if (buttons[0]) buttons[0].click();
  }
  initCountryExplorer();

  /* ---------- OPPORTUNITY FILTER ---------- */
  function initOppFilter() {
    var filterBtns = document.querySelectorAll('.ega-opp-filter');
    var cards = document.querySelectorAll('.ega-opp-item');
    if (!filterBtns.length || !cards.length) return;
    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var sector = btn.dataset.sector;
        filterBtns.forEach(function (b) { b.classList.toggle('active', b === btn); });
        cards.forEach(function (c) {
          var show = sector === 'all' || c.dataset.sector === sector;
          c.style.display = show ? '' : 'none';
        });
      });
    });
  }
  initOppFilter();

  /* ---------- PORTAL BARS ---------- */
  function initPortalBars() {
    var bars = document.querySelectorAll('.ega-portal-bar-fill');
    if (!bars.length) return;
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.width = entry.target.dataset.width;
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });
    bars.forEach(function (el) { el.style.width = '0'; el.style.transition = 'width 1.1s cubic-bezier(0.16,1,0.3,1)'; obs.observe(el); });
  }
  initPortalBars();

  /* ---------- CONTACT FORM AJAX ---------- */
  function initContactForm() {
    var form = document.getElementById('ega-contact-form');
    if (!form) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      var status = document.getElementById('ega-form-status');
      btn.disabled = true;
      btn.textContent = btn.dataset.sending || 'Sending…';
      var fd = new FormData(form);
      var data = {};
      fd.forEach(function (v, k) { data[k] = v; });

      // WordPress AJAX
      if (typeof egaAjax !== 'undefined') {
        data.action = 'ega_contact';
        data.nonce = egaAjax.nonce;
        fetch(egaAjax.ajaxUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(data),
        })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res.success) {
              if (status) { status.textContent = btn.dataset.success || 'Thank you.'; status.className = 'ega-form-success'; }
              form.reset();
            } else {
              if (status) { status.textContent = btn.dataset.error || 'Error.'; status.className = 'ega-form-error'; }
            }
            btn.disabled = false;
            btn.textContent = btn.dataset.label || 'Send';
          })
          .catch(function () {
            if (status) { status.textContent = btn.dataset.error || 'Error.'; status.className = 'ega-form-error'; }
            btn.disabled = false;
            btn.textContent = btn.dataset.label || 'Send';
          });
      }
    });
  }
  initContactForm();

  /* ---------- APPOINTMENT FORM AJAX ---------- */
  function initAppointmentForm() {
    var form = document.getElementById('ega-appointment-form');
    if (!form) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      var status = document.getElementById('ega-appt-status');
      btn.disabled = true;
      var fd = new FormData(form);
      var data = {};
      fd.forEach(function (v, k) { data[k] = v; });
      if (typeof egaAjax !== 'undefined') {
        data.action = 'ega_appointment';
        data.nonce = egaAjax.nonce;
        fetch(egaAjax.ajaxUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(data),
        })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res.success && status) { status.textContent = btn.dataset.success || 'Request received.'; status.className = 'ega-form-success'; form.reset(); }
            btn.disabled = false;
          })
          .catch(function () { btn.disabled = false; });
      }
    });
  }
  initAppointmentForm();

  /* ---------- NEWSLETTER ---------- */
  var nlForm = document.getElementById('ega-newsletter-form');
  if (nlForm) {
    nlForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var status = document.getElementById('ega-nl-status');
      if (status) { status.textContent = status.dataset.success || 'Subscribed.'; nlForm.style.display = 'none'; status.style.display = 'block'; }
    });
  }

  /* ---------- SMOOTH SCROLL ---------- */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var id = a.getAttribute('href');
      if (id === '#') return;
      var target = document.querySelector(id);
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

})();
