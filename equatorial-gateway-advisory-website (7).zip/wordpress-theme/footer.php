</main>

<?php
$nav_items = [
    ['label' => __('Home', 'ega'), 'slug' => ''],
    ['label' => __('About', 'ega'), 'slug' => 'about'],
    ['label' => __('Services', 'ega'), 'slug' => 'services'],
    ['label' => __('Opportunities', 'ega'), 'slug' => 'opportunities'],
    ['label' => __('Why Central Africa', 'ega'), 'slug' => 'why-central-africa'],
    ['label' => __('Sectors', 'ega'), 'slug' => 'sectors'],
    ['label' => __('Process', 'ega'), 'slug' => 'process'],
    ['label' => __('Insights', 'ega'), 'slug' => 'insights'],
    ['label' => __('Contact', 'ega'), 'slug' => 'contact'],
    ['label' => __('Investor Portal', 'ega'), 'slug' => 'portal'],
];
$email = get_theme_mod('ega_email', 'contact@equatorialgatewayadvisory.com');
$year = date('Y');
?>

<footer class="ega-footer" role="contentinfo">
    <div class="grid-veil" style="position:absolute;inset:0;opacity:0.3;pointer-events:none;"></div>
    <div class="ega-container" style="position:relative;">
        <div class="ega-footer-grid">
            <!-- Brand -->
            <div>
                <div style="display:flex;align-items:center;gap:12px;">
                    <svg viewBox="0 0 120 120" style="width:44px;height:44px;color:#fff;" fill="none">
                        <g><path d="M60 10 L67 53 L60 60 L53 53 Z" fill="currentColor"/><path d="M60 110 L53 67 L60 60 L67 67 Z" fill="currentColor" opacity="0.7"/></g>
                        <path d="M22 92 L48 66 L62 78 L92 40" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M78 40 L92 40 L92 54" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <div>
                        <p style="font-family:var(--font-display);font-size:1.5rem;font-weight:800;letter-spacing:-0.04em;color:#fff;">EGA</p>
                        <p style="font-size:10px;text-transform:uppercase;letter-spacing:0.24em;color:var(--petrol-300);">Equatorial Gateway Advisory</p>
                    </div>
                </div>
                <p style="margin-top:24px;max-width:280px;font-size:14px;line-height:1.7;color:var(--petrol-200);">
                    <?php echo esc_html(ega_t('footer_tagline', 'Connecting global capital with Central African opportunity.')); ?>
                </p>
                <a href="mailto:<?php echo esc_attr($email); ?>" class="link-underline" style="display:inline-block;margin-top:24px;font-size:14px;font-weight:500;color:var(--ember-300);">
                    <?php echo esc_html($email); ?>
                </a>
            </div>

            <!-- Explore -->
            <div>
                <p class="eyebrow" style="margin-bottom:20px;color:var(--petrol-400);"><?php esc_html_e('Explore', 'ega'); ?></p>
                <ul>
                    <?php foreach (array_slice($nav_items, 0, 5) as $item) : ?>
                        <li><a href="<?php echo esc_url(home_url('/' . $item['slug'] . '/')); ?>"><?php echo esc_html($item['label']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Company -->
            <div>
                <p class="eyebrow" style="margin-bottom:20px;color:var(--petrol-400);"><?php esc_html_e('Company', 'ega'); ?></p>
                <ul>
                    <?php foreach (array_slice($nav_items, 5) as $item) : ?>
                        <li><a href="<?php echo esc_url(home_url('/' . $item['slug'] . '/')); ?>"><?php echo esc_html($item['label']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Newsletter -->
            <div>
                <p class="eyebrow" style="margin-bottom:20px;color:var(--petrol-400);"><?php echo esc_html(ega_t('footer_newsletter_title', 'Intelligence briefing')); ?></p>
                <p style="margin-bottom:16px;font-size:14px;line-height:1.7;color:var(--petrol-200);">
                    <?php echo esc_html(ega_t('footer_newsletter_text', 'Periodic, confidential intelligence on Central African markets. No noise.')); ?>
                </p>
                <form class="newsletter-form" id="ega-newsletter-form">
                    <input type="email" required placeholder="<?php esc_attr_e('Work email', 'ega'); ?>" class="newsletter-input" aria-label="<?php esc_attr_e('Work email', 'ega'); ?>">
                    <button type="submit" class="newsletter-btn"><?php esc_html_e('Subscribe', 'ega'); ?></button>
                </form>
                <p id="ega-nl-status" style="display:none;margin-top:12px;padding:12px 16px;border-radius:12px;border:1px solid rgba(200,83,31,0.4);background:rgba(200,83,31,0.1);font-size:14px;color:var(--ember-200);" data-success="<?php esc_attr_e("You're subscribed.", 'ega'); ?>"></p>
            </div>
        </div>

        <p class="ega-footer-disclaimer">
            <?php echo esc_html(ega_t('footer_disclaimer', 'EGA provides advisory and facilitation services. Nothing on this site constitutes an offer of securities or investment advice within the meaning of any jurisdiction.')); ?>
        </p>

        <div class="ega-footer-bottom">
            <p>&copy; <?php echo $year; ?> Equatorial Gateway Advisory. <?php esc_html_e('All rights reserved.', 'ega'); ?></p>
            <div class="ega-footer-legal">
                <span><?php esc_html_e('Privacy', 'ega'); ?></span>
                <span><?php esc_html_e('Terms', 'ega'); ?></span>
                <span><?php esc_html_e('Confidentiality', 'ega'); ?></span>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
