<?php
/**
 * Template Name: EGA Home
 * Home page — all sections.
 * @package ega
 */
get_header();
$sectors = ega_sectors();
$countries = ega_countries();
$steps = ega_process_steps();
$stats = ega_stats();
$marquee_items = [__('Sovereign Funds', 'ega'), __('Private Equity', 'ega'), __('Family Offices', 'ega'), __('Development Finance', 'ega'), __('Strategic Partners', 'ega'), __('Project Owners', 'ega'), __('Governments', 'ega'), __('Global Investors', 'ega')];
?>

<!-- ========== HERO ========== -->
<section class="ega-hero">
    <div class="ega-hero-bg"><img src="<?php echo esc_url(EGA_URI . '/assets/images/hero.jpg'); ?>" alt="<?php esc_attr_e('Aerial view of Central African port and rainforest', 'ega'); ?>" class="kenburns" loading="eager"></div>
    <div class="ega-hero-gradient1"></div>
    <div class="ega-hero-gradient2"></div>

    <svg viewBox="0 0 120 120" class="ega-compass-lg compass-spin" fill="none">
        <circle cx="60" cy="60" r="46" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" stroke-dasharray="2 7"/>
        <path d="M60 10 L67 53 L60 60 L53 53 Z" fill="currentColor"/>
        <path d="M60 110 L53 67 L60 60 L67 67 Z" fill="currentColor" opacity="0.7"/>
        <path d="M10 60 L53 53 L60 60 L53 67 Z" fill="currentColor" opacity="0.55"/>
        <path d="M110 60 L67 67 L60 60 L67 53 Z" fill="currentColor" opacity="0.55"/>
    </svg>

    <div class="ega-hero-content">
        <div class="ega-hero-eyebrow reveal">
            <span class="line"></span>
            <span class="eyebrow" style="color:var(--ember-300);"><?php esc_html_e('Republic of Congo · Central Africa', 'ega'); ?></span>
        </div>
        <h1>
            <span class="reveal" data-delay="0.1"><?php echo esc_html(ega_t('hero_title_1', 'Connecting Global Capital')); ?></span><br>
            <span class="reveal text-gradient" data-delay="0.25"><?php echo esc_html(ega_t('hero_title_2', 'with Central African Opportunities.')); ?></span>
        </h1>
        <p class="subtitle reveal" data-delay="0.4"><?php echo esc_html(ega_t('hero_subtitle', 'Equatorial Gateway Advisory facilitates strategic investment across the Republic of Congo and Central Africa through trusted advisory, institutional relationships and project execution.')); ?></p>
        <div class="ega-hero-ctas reveal" data-delay="0.55">
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="ega-btn-ember"><?php echo esc_html(ega_t('hero_cta_primary', 'Schedule a Meeting')); ?> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
            <a href="<?php echo esc_url(home_url('/opportunities/')); ?>" class="ega-btn-outline"><?php echo esc_html(ega_t('hero_cta_secondary', 'Explore Opportunities')); ?></a>
        </div>
        <div class="ega-hero-badges reveal" data-delay="0.8">
            <?php foreach ([__('Government relations', 'ega'), __('Institutional discretion', 'ega'), __('On-the-ground execution', 'ega')] as $badge) : ?>
                <span><span class="dot"></span> <?php echo esc_html($badge); ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="ega-hero-scroll bounce-arrow">
        <span><?php esc_html_e('Scroll to discover', 'ega'); ?></span>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M6 13l6 6 6-6"/></svg>
    </div>
</section>

<!-- ========== MARQUEE ========== -->
<div class="ega-marquee">
    <div class="ega-marquee-inner marquee-track">
        <?php $all = array_merge($marquee_items, $marquee_items); foreach ($all as $item) : ?>
            <span><?php echo esc_html($item); ?> <span class="diamond">✦</span></span>
        <?php endforeach; ?>
    </div>
</div>

<!-- ========== ABOUT ========== -->
<section class="ega-section">
    <div class="ega-container">
        <div class="ega-about-grid">
            <div>
                <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('Who we are', 'ega'), 'title' => __('A trusted bridge between international capital and African opportunity.', 'ega')]); ?>
                <p class="reveal" data-delay="0.1" style="margin-top:24px;font-size:16px;line-height:1.7;color:var(--slatey-600);"><?php esc_html_e('EGA exists to make Central Africa investable with confidence. We sit at the intersection of governments, investors and operators, translating ambition into structured, executable transactions.', 'ega'); ?></p>
                <p class="reveal" data-delay="0.15" style="margin-top:16px;font-size:16px;line-height:1.7;color:var(--slatey-600);"><?php esc_html_e('From sovereign funds and private equity to family offices and strategic corporates, we give principals privileged access, rigorous diligence and the institutional relationships required to move from interest to capital deployed. Our work is discreet, our standards are global, and our presence is local.', 'ega'); ?></p>
                <div class="ega-about-points reveal" data-delay="0.2">
                    <?php foreach ([
                        [__('Access', 'ega'), __('Direct relationships with ministries, agencies and project owners across the region.', 'ega')],
                        [__('Intelligence', 'ega'), __('Ground-truth market reading that no desk in London or Dubai can replicate.', 'ega')],
                        [__('Execution', 'ega'), __('We stay until capital is deployed and milestones are met — not just introduced.', 'ega')],
                    ] as $pt) : ?>
                        <div class="ega-about-point">
                            <h3><?php echo esc_html($pt[0]); ?></h3>
                            <p><?php echo esc_html($pt[1]); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
                <a href="<?php echo esc_url(home_url('/about/')); ?>" class="link-underline reveal" data-delay="0.25" style="display:inline-flex;align-items:center;gap:8px;margin-top:36px;font-size:14px;font-weight:600;color:var(--ember-500);">
                    <?php esc_html_e('Read our full story', 'ega'); ?>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </a>
            </div>
            <div class="reveal" data-delay="0.1">
                <div class="ega-about-image">
                    <img src="<?php echo esc_url(EGA_URI . '/assets/images/boardroom.jpg'); ?>" alt="<?php esc_attr_e('Executive boardroom at dusk', 'ega'); ?>" loading="lazy">
                    <div class="overlay"></div>
                    <div class="quote-card glass">
                        <p style="font-family:var(--font-serif);font-size:18px;font-style:italic;color:var(--petrol-900);">&ldquo;<?php echo esc_html(ega_t('cta_title', 'Capital moves where trust leads.')); ?>&rdquo;</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ========== STATS ========== -->
<section class="ega-section-petrol ega-section">
    <div class="grid-veil"></div>
    <div class="ega-container" style="position:relative;">
        <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('By the numbers', 'ega'), 'title' => __('Scale, reach and rigour.', 'ega'), 'light' => true]); ?>
        <div class="ega-stats">
            <?php foreach ($stats as $s) : ?>
                <div class="ega-stat reveal">
                    <p class="number"><span data-counter="<?php echo esc_attr($s['value']); ?>" data-prefix="<?php echo esc_attr($s['prefix']); ?>" data-suffix="<?php echo esc_attr($s['suffix']); ?>" data-decimals="<?php echo esc_attr($s['decimals']); ?>">0</span></p>
                    <p class="label"><?php echo esc_html($s['label']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ========== SECTORS ========== -->
<section class="ega-section">
    <div class="ega-container">
        <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-end;gap:24px;">
            <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('Where capital meets opportunity', 'ega'), 'title' => __('Investment sectors.', 'ega'), 'subtitle' => __('Twelve priority sectors shaping the next decade of Central African growth — each mapped to credible projects and counterparties.', 'ega')]); ?>
            <a href="<?php echo esc_url(home_url('/sectors/')); ?>" class="link-underline reveal" style="font-size:14px;font-weight:600;color:var(--ember-500);display:inline-flex;align-items:center;gap:8px;"><?php esc_html_e('Explore all sectors', 'ega'); ?> <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        </div>
        <div class="ega-grid-3" style="margin-top:56px;">
            <?php foreach ($sectors as $s) : ?>
                <a href="<?php echo esc_url(home_url('/sectors/#' . $s['id'])); ?>" class="ega-card lift reveal" style="padding:0;overflow:hidden;">
                    <?php if (!empty($s['image'])) : ?>
                        <div style="position:relative;height:160px;overflow:hidden;">
                            <img src="<?php echo esc_url($s['image']); ?>" alt="<?php echo esc_attr($s['name']); ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform 0.7s cubic-bezier(0.16,1,0.3,1);">
                            <div style="position:absolute;inset:0;background:linear-gradient(to top,var(--card),transparent);"></div>
                            <span style="position:absolute;left:16px;top:16px;width:40px;height:40px;border-radius:12px;background:rgba(255,255,255,0.9);display:flex;align-items:center;justify-content:center;font-size:1.25rem;box-shadow:0 4px 12px rgba(0,0,0,0.1);"><?php echo $s['icon']; ?></span>
                        </div>
                    <?php else : ?>
                        <div style="padding:28px 24px 0;"><span class="icon"><?php echo $s['icon']; ?></span></div>
                    <?php endif; ?>
                    <div style="padding:<?php echo !empty($s['image']) ? '16px 24px 24px' : '12px 24px 24px'; ?>;">
                        <h3><?php echo esc_html($s['name']); ?></h3>
                        <p><?php echo esc_html($s['blurb']); ?></p>
                        <span class="learn-more"><?php esc_html_e('Learn more', 'ega'); ?> <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ========== CINEMATIC PHOTO STRIP ========== -->
<section style="overflow:hidden;padding:16px 0;">
    <div class="ega-container reveal">
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;">
            <?php
            $strip_images = [
                ['src' => EGA_URI . '/assets/images/energy.jpg', 'alt' => __('Energy infrastructure', 'ega')],
                ['src' => EGA_URI . '/assets/images/mining.jpg', 'alt' => __('Mining operations', 'ega')],
                ['src' => EGA_URI . '/assets/images/agriculture.jpg', 'alt' => __('Agricultural landscapes', 'ega')],
                ['src' => EGA_URI . '/assets/images/digital.jpg', 'alt' => __('Data centre technology', 'ega')],
                ['src' => EGA_URI . '/assets/images/logistics.jpg', 'alt' => __('Port logistics', 'ega')],
            ];
            foreach ($strip_images as $img) : ?>
                <div style="position:relative;aspect-ratio:3/2;overflow:hidden;border-radius:16px;">
                    <img src="<?php echo esc_url($img['src']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform 0.7s cubic-bezier(0.16,1,0.3,1);">
                    <div style="position:absolute;inset:0;background:rgba(4,18,27,0.3);transition:opacity 0.5s;"></div>
                </div>
            <?php endforeach; ?>
        </div>
        <style>
            @media (min-width: 768px) {
                .ega-container .reveal > div { grid-template-columns: repeat(5, 1fr) !important; }
            }
            .ega-container .reveal > div > div:hover img { transform: scale(1.1); }
            .ega-container .reveal > div > div:hover div { opacity: 0 !important; }
        </style>
    </div>
</section>

<!-- ========== WHY CENTRAL AFRICA ========== -->
<section class="ega-section ega-section-soft">
    <div class="ega-container">
        <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('Why Central Africa', 'ega'), 'title' => __('A region at an inflection point.', 'ega'), 'subtitle' => __('Resource depth, strategic geography and reforming economies are converging. We help you position before the consensus arrives.', 'ega')]); ?>
        <div class="ega-countries-grid" style="margin-top:56px;">
            <div>
                <div class="ega-country-buttons">
                    <?php foreach ($countries as $c) : ?>
                        <button class="ega-country-btn" data-country="<?php echo esc_attr($c['id']); ?>">
                            <span class="flag"><?php echo $c['flag']; ?></span>
                            <span class="name"><?php echo esc_html($c['name']); ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
                <p style="margin-top:16px;font-size:12px;color:var(--slatey-500);"><?php esc_html_e('Select a country to view its profile', 'ega'); ?></p>
            </div>
            <div>
                <?php foreach ($countries as $c) : ?>
                    <div class="ega-country-panel ega-country-detail" data-country="<?php echo esc_attr($c['id']); ?>" style="display:none;">
                        <span class="bg-flag"><?php echo $c['flag']; ?></span>
                        <div class="header">
                            <span class="flag"><?php echo $c['flag']; ?></span>
                            <div>
                                <h3><?php echo esc_html($c['name']); ?></h3>
                                <p class="capital"><?php echo esc_html($c['capital']); ?></p>
                            </div>
                        </div>
                        <p class="tagline"><?php echo esc_html($c['tagline']); ?></p>
                        <p class="highlights"><?php echo esc_html($c['highlights']); ?></p>
                        <div class="stats-row">
                            <div><p class="val"><?php echo esc_html($c['gdp']); ?></p><p class="lbl">GDP</p></div>
                            <div><p class="val"><?php echo esc_html($c['pop']); ?></p><p class="lbl">Population</p></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- ========== OPPORTUNITIES ========== -->
<section class="ega-section">
    <div class="ega-container">
        <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-end;gap:24px;">
            <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('Live & curated', 'ega'), 'title' => __('Investment opportunities.', 'ega'), 'subtitle' => __('A selection of institutionally screened opportunities. Full data rooms are available to qualified investors through the secure portal.', 'ega')]); ?>
            <a href="<?php echo esc_url(home_url('/opportunities/')); ?>" class="link-underline" style="font-size:14px;font-weight:600;color:var(--ember-500);display:inline-flex;align-items:center;gap:8px;"><?php esc_html_e('See all opportunities', 'ega'); ?> <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        </div>
        <div class="ega-grid-3" style="margin-top:56px;">
            <?php
            $opps = new WP_Query(['post_type' => 'ega_opportunity', 'posts_per_page' => 9, 'post_status' => 'publish']);
            if ($opps->have_posts()) :
                while ($opps->have_posts()) : $opps->the_post();
                    get_template_part('template-parts/opp-card');
                endwhile;
                wp_reset_postdata();
            else :
                // Fallback static content
                echo '<p style="grid-column:1/-1;text-align:center;padding:64px 0;color:var(--slatey-500);">' . esc_html__('Opportunities coming soon. Contact us to learn more.', 'ega') . '</p>';
            endif;
            ?>
        </div>
    </div>
</section>

<!-- ========== PROCESS ========== -->
<section class="ega-section ega-section-soft">
    <div class="ega-narrow">
        <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('How we work', 'ega'), 'title' => __('Our process.', 'ega'), 'subtitle' => __('A disciplined methodology that de-risks every stage — from first conversation to long-term monitoring.', 'ega'), 'center' => true]); ?>
        <div class="ega-timeline" style="margin-top:64px;">
            <div class="ega-timeline-line"></div>
            <?php foreach ($steps as $step) : ?>
                <div class="ega-timeline-step reveal">
                    <div class="ega-timeline-dot"><?php echo esc_html($step['n']); ?></div>
                    <div class="ega-timeline-card lift">
                        <h3><?php echo esc_html($step['title']); ?></h3>
                        <p><?php echo esc_html($step['text']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ========== INSIGHTS ========== -->
<section class="ega-section">
    <div class="ega-container">
        <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-end;gap:24px;">
            <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('Intelligence', 'ega'), 'title' => __('Insights & research.', 'ega'), 'subtitle' => __('Market analysis, economic reports and sector intelligence, authored by our advisory team.', 'ega')]); ?>
            <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="link-underline" style="font-size:14px;font-weight:600;color:var(--ember-500);display:inline-flex;align-items:center;gap:8px;"><?php esc_html_e('Read all insights', 'ega'); ?> <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        </div>
        <div class="ega-grid-3" style="margin-top:56px;">
            <?php
            $ins = new WP_Query(['post_type' => 'ega_insight', 'posts_per_page' => 3, 'post_status' => 'publish']);
            if ($ins->have_posts()) :
                while ($ins->have_posts()) : $ins->the_post();
                    get_template_part('template-parts/insight-card');
                endwhile;
                wp_reset_postdata();
            else :
                echo '<p style="grid-column:1/-1;text-align:center;padding:64px 0;color:var(--slatey-500);">' . esc_html__('Insights coming soon.', 'ega') . '</p>';
            endif;
            ?>
        </div>
    </div>
</section>

<!-- ========== CTA ========== -->
<?php get_template_part('template-parts/cta-section'); ?>

<?php get_footer(); ?>
