<?php
/**
 * EGA — Equatorial Gateway Advisory
 * Theme Functions
 *
 * @package ega
 */

defined('ABSPATH') || exit;

define('EGA_VERSION', '1.0.0');
define('EGA_DIR', get_template_directory());
define('EGA_URI', get_template_directory_uri());

/* =========================================
   THEME SETUP
   ========================================= */
add_action('after_setup_theme', function () {
    load_theme_textdomain('ega', EGA_DIR . '/languages');

    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);
    add_theme_support('custom-logo', ['height' => 80, 'width' => 200, 'flex-height' => true, 'flex-width' => true]);
    add_theme_support('editor-styles');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('align-wide');

    add_image_size('ega-hero', 1920, 1080, true);
    add_image_size('ega-card', 800, 600, true);
    add_image_size('ega-og', 1200, 630, true);

    register_nav_menus([
        'primary'  => __('Primary Navigation', 'ega'),
        'footer'   => __('Footer Navigation', 'ega'),
        'legal'    => __('Legal Links', 'ega'),
    ]);
});

/* =========================================
   ENQUEUE ASSETS
   ========================================= */
add_action('wp_enqueue_scripts', function () {
    // Google Fonts loaded in CSS @import, no need for separate enqueue.
    wp_enqueue_style('ega-theme', EGA_URI . '/assets/css/theme.css', [], EGA_VERSION);

    wp_enqueue_script('ega-theme', EGA_URI . '/assets/js/theme.js', [], EGA_VERSION, true);

    wp_localize_script('ega-theme', 'egaAjax', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('ega_nonce'),
    ]);
});

/* =========================================
   CUSTOM POST TYPES
   ========================================= */
add_action('init', function () {
    // Opportunities
    register_post_type('ega_opportunity', [
        'labels' => [
            'name' => __('Opportunities', 'ega'),
            'singular_name' => __('Opportunity', 'ega'),
            'add_new_item' => __('Add New Opportunity', 'ega'),
            'edit_item' => __('Edit Opportunity', 'ega'),
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'opportunities'],
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'menu_icon' => 'dashicons-chart-area',
        'show_in_rest' => true,
    ]);

    // Insights
    register_post_type('ega_insight', [
        'labels' => [
            'name' => __('Insights', 'ega'),
            'singular_name' => __('Insight', 'ega'),
            'add_new_item' => __('Add New Insight', 'ega'),
            'edit_item' => __('Edit Insight', 'ega'),
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'insights'],
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'menu_icon' => 'dashicons-analytics',
        'show_in_rest' => true,
    ]);

    // Sectors Taxonomy
    register_taxonomy('ega_sector', ['ega_opportunity', 'ega_insight'], [
        'labels' => ['name' => __('Sectors', 'ega'), 'singular_name' => __('Sector', 'ega')],
        'public' => true,
        'hierarchical' => true,
        'rewrite' => ['slug' => 'sector'],
        'show_in_rest' => true,
    ]);

    // Countries Taxonomy
    register_taxonomy('ega_country', ['ega_opportunity'], [
        'labels' => ['name' => __('Countries', 'ega'), 'singular_name' => __('Country', 'ega')],
        'public' => true,
        'hierarchical' => true,
        'rewrite' => ['slug' => 'country'],
        'show_in_rest' => true,
    ]);

    // Insight Categories
    register_taxonomy('ega_insight_category', ['ega_insight'], [
        'labels' => ['name' => __('Insight Categories', 'ega'), 'singular_name' => __('Insight Category', 'ega')],
        'public' => true,
        'hierarchical' => true,
        'rewrite' => ['slug' => 'insight-category'],
        'show_in_rest' => true,
    ]);
});

/* =========================================
   CUSTOM META BOXES FOR OPPORTUNITIES
   ========================================= */
add_action('add_meta_boxes', function () {
    add_meta_box('ega_opp_details', __('Investment Details', 'ega'), 'ega_opp_meta_box', 'ega_opportunity', 'side', 'high');
});

function ega_opp_meta_box($post) {
    wp_nonce_field('ega_opp_nonce', 'ega_opp_nonce');
    $fields = [
        'ega_investment_amount' => __('Investment Amount', 'ega'),
        'ega_target_roi' => __('Target ROI', 'ega'),
        'ega_status' => __('Status', 'ega'),
    ];
    foreach ($fields as $key => $label) {
        $value = get_post_meta($post->ID, $key, true);
        echo '<p><label><strong>' . esc_html($label) . '</strong></label><br>';
        echo '<input type="text" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%;" /></p>';
    }
}

add_action('save_post_ega_opportunity', function ($post_id) {
    if (!isset($_POST['ega_opp_nonce']) || !wp_verify_nonce($_POST['ega_opp_nonce'], 'ega_opp_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    foreach (['ega_investment_amount', 'ega_target_roi', 'ega_status'] as $key) {
        if (isset($_POST[$key])) {
            update_post_meta($post_id, $key, sanitize_text_field($_POST[$key]));
        }
    }
});

/* =========================================
   INSIGHT READ TIME META
   ========================================= */
add_action('add_meta_boxes', function () {
    add_meta_box('ega_insight_meta', __('Insight Details', 'ega'), 'ega_insight_meta_box', 'ega_insight', 'side', 'high');
});

function ega_insight_meta_box($post) {
    wp_nonce_field('ega_insight_nonce', 'ega_insight_nonce');
    $min = get_post_meta($post->ID, 'ega_read_min', true);
    echo '<p><label><strong>' . __('Read time (min)', 'ega') . '</strong></label><br>';
    echo '<input type="number" name="ega_read_min" value="' . esc_attr($min) . '" style="width:100%;" /></p>';
}

add_action('save_post_ega_insight', function ($post_id) {
    if (!isset($_POST['ega_insight_nonce']) || !wp_verify_nonce($_POST['ega_insight_nonce'], 'ega_insight_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['ega_read_min'])) {
        update_post_meta($post_id, 'ega_read_min', intval($_POST['ega_read_min']));
    }
});

/* =========================================
   CONTACT FORM AJAX
   ========================================= */
add_action('wp_ajax_ega_contact', 'ega_handle_contact');
add_action('wp_ajax_nopriv_ega_contact', 'ega_handle_contact');

function ega_handle_contact() {
    check_ajax_referer('ega_nonce', 'nonce');

    $name = sanitize_text_field($_POST['name'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message) || !is_email($email)) {
        wp_send_json_error(['message' => 'Invalid submission']);
    }

    // Store as a private post
    $post_id = wp_insert_post([
        'post_type'   => 'ega_enquiry',
        'post_title'  => $name . ' — ' . $email,
        'post_content' => $message,
        'post_status' => 'private',
    ]);

    if ($post_id) {
        update_post_meta($post_id, 'ega_company', sanitize_text_field($_POST['company'] ?? ''));
        update_post_meta($post_id, 'ega_country', sanitize_text_field($_POST['country'] ?? ''));
        update_post_meta($post_id, 'ega_phone', sanitize_text_field($_POST['phone'] ?? ''));
        update_post_meta($post_id, 'ega_sector', sanitize_text_field($_POST['sector'] ?? ''));
        update_post_meta($post_id, 'ega_budget', sanitize_text_field($_POST['budget'] ?? ''));
        update_post_meta($post_id, 'ega_email', $email);
    }

    // Optionally send email
    $admin_email = get_option('admin_email');
    $subject = '[EGA] New enquiry from ' . $name;
    $body = "Name: {$name}\nEmail: {$email}\nCompany: " . ($_POST['company'] ?? '') . "\nCountry: " . ($_POST['country'] ?? '') . "\nSector: " . ($_POST['sector'] ?? '') . "\nBudget: " . ($_POST['budget'] ?? '') . "\n\nMessage:\n{$message}";
    wp_mail($admin_email, $subject, $body, ['Reply-To: ' . $email]);

    wp_send_json_success(['message' => 'Enquiry received']);
}

/* =========================================
   APPOINTMENT FORM AJAX
   ========================================= */
add_action('wp_ajax_ega_appointment', 'ega_handle_appointment');
add_action('wp_ajax_nopriv_ega_appointment', 'ega_handle_appointment');

function ega_handle_appointment() {
    check_ajax_referer('ega_nonce', 'nonce');

    $name = sanitize_text_field($_POST['name'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');

    if (empty($name) || empty($email) || !is_email($email)) {
        wp_send_json_error(['message' => 'Invalid submission']);
    }

    $post_id = wp_insert_post([
        'post_type'   => 'ega_appointment',
        'post_title'  => $name . ' — ' . ($POST['preferredDate'] ?? ''),
        'post_content' => sanitize_textarea_field($_POST['notes'] ?? ''),
        'post_status' => 'private',
    ]);

    if ($post_id) {
        update_post_meta($post_id, 'ega_email', $email);
        update_post_meta($post_id, 'ega_organisation', sanitize_text_field($_POST['organisation'] ?? ''));
        update_post_meta($post_id, 'ega_preferred_date', sanitize_text_field($_POST['preferredDate'] ?? ''));
        update_post_meta($post_id, 'ega_topic', sanitize_text_field($_POST['topic'] ?? ''));
    }

    $admin_email = get_option('admin_email');
    wp_mail($admin_email, '[EGA] Appointment request: ' . $name, "Name: {$name}\nEmail: {$email}\nDate: " . ($_POST['preferredDate'] ?? '') . "\nTopic: " . ($_POST['topic'] ?? ''));

    wp_send_json_success(['message' => 'Appointment request received']);
}

/* =========================================
   PRIVATE POST TYPE: ENQUIRIES + APPOINTMENTS
   ========================================= */
add_action('init', function () {
    register_post_type('ega_enquiry', [
        'labels' => ['name' => __('Enquiries', 'ega'), 'singular_name' => __('Enquiry', 'ega')],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'supports' => ['title', 'editor', 'custom-fields'],
        'menu_icon' => 'dashicons-email-alt',
        'capabilities' => ['create_posts' => false],
        'map_meta_cap' => true,
    ]);

    register_post_type('ega_appointment', [
        'labels' => ['name' => __('Appointments', 'ega'), 'singular_name' => __('Appointment', 'ega')],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'supports' => ['title', 'editor', 'custom-fields'],
        'menu_icon' => 'dashicons-calendar-alt',
        'capabilities' => ['create_posts' => false],
        'map_meta_cap' => true,
    ]);
});

/* =========================================
   SEO: STRUCTURED DATA
   ========================================= */
add_action('wp_head', function () {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'ProfessionalService',
        'name' => 'Equatorial Gateway Advisory',
        'alternateName' => 'EGA',
        'description' => get_bloginfo('description'),
        'email' => 'contact@equatorialgatewayadvisory.com',
        'url' => home_url(),
        'areaServed' => ['Republic of Congo', 'Cameroon', 'Gabon', 'DR Congo', 'Equatorial Guinea', 'Chad', 'Central African Republic', 'Angola'],
        'serviceType' => 'Investment Advisory',
    ];
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";

    // Open Graph fallback (if no SEO plugin)
    if (!defined('WPSEO_VERSION') && !defined('RANK_MATH_VERSION')) {
        echo '<meta property="og:type" content="website" />' . "\n";
        echo '<meta property="og:site_name" content="Equatorial Gateway Advisory" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr(wp_title('—', false, 'right') . get_bloginfo('name')) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(get_bloginfo('description')) . '" />' . "\n";
        echo '<meta property="og:image" content="' . esc_url(EGA_URI . '/assets/images/og.jpg') . '" />' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
    }
});

/* =========================================
   CUSTOMIZER: FOOTER & CONTACT DETAILS
   ========================================= */
add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_section('ega_contact', [
        'title' => __('EGA Contact Details', 'ega'),
        'priority' => 30,
    ]);

    $fields = [
        'ega_email' => ['Email', 'contact@equatorialgatewayadvisory.com'],
        'ega_offices' => ['Offices', 'Brazzaville · Pointe-Noire · Regional Central Africa'],
        'ega_engagement' => ['Engagement', 'By appointment — globally, in confidence'],
    ];

    foreach ($fields as $key => [$label, $default]) {
        $wp_customize->add_setting($key, ['default' => $default, 'sanitize_callback' => 'sanitize_text_field']);
        $wp_customize->add_control($key, ['label' => $label, 'section' => 'ega_contact', 'type' => 'text']);
    }
});

/* =========================================
   HELPER FUNCTIONS
   ========================================= */

/**
 * Get current locale (Polylang or WPML aware).
 */
function ega_locale(): string {
    if (function_exists('pll_current_language')) {
        return pll_current_language('slug') ?: 'en';
    }
    if (defined('ICL_LANGUAGE_CODE')) {
        return ICL_LANGUAGE_CODE ?: 'en';
    }
    return substr(get_locale(), 0, 2);
}

/**
 * Get translation for a given key (Polylang string registration).
 */
function ega_t(string $key, string $default = ''): string {
    if (function_exists('pll__')) {
        return pll__($key) ?: $default;
    }
    return $default ?: $key;
}

/**
 * Register strings for Polylang translation.
 */
add_action('init', function () {
    if (!function_exists('pll_register_string')) return;

    $strings = [
        'hero_title_1' => 'Connecting Global Capital',
        'hero_title_2' => 'with Central African Opportunities.',
        'hero_subtitle' => 'Equatorial Gateway Advisory facilitates strategic investment across the Republic of Congo and Central Africa through trusted advisory, institutional relationships and project execution.',
        'hero_cta_primary' => 'Schedule a Meeting',
        'hero_cta_secondary' => 'Explore Opportunities',
        'nav_cta' => 'Schedule a Meeting',
        'footer_tagline' => 'Connecting global capital with Central African opportunity.',
        'footer_newsletter_title' => 'Intelligence briefing',
        'footer_newsletter_text' => 'Periodic, confidential intelligence on Central African markets. No noise.',
        'footer_disclaimer' => 'EGA provides advisory and facilitation services. Nothing on this site constitutes an offer of securities or investment advice within the meaning of any jurisdiction.',
        'cta_title' => 'Capital moves where trust leads.',
        'cta_subtitle' => 'Open a confidential dialogue with our advisory team and explore how EGA can structure your entry into Central Africa.',
        'contact_form_success' => 'Thank you. A senior advisor will be in touch shortly.',
        'contact_form_error' => 'Something went wrong. Please try again or email us directly.',
    ];

    foreach ($strings as $name => $default) {
        pll_register_string($name, $default, 'EGA Theme');
    }
});

/* =========================================
   ADMIN COLUMNS FOR OPPORTUNITIES
   ========================================= */
add_filter('manage_ega_opportunity_posts_columns', function ($cols) {
    $new = [];
    foreach ($cols as $k => $v) {
        $new[$k] = $v;
        if ($k === 'title') {
            $new['ega_amount'] = __('Investment', 'ega');
            $new['ega_roi'] = __('ROI', 'ega');
            $new['ega_status_col'] = __('Status', 'ega');
        }
    }
    return $new;
});

add_action('manage_ega_opportunity_posts_custom_column', function ($col, $id) {
    switch ($col) {
        case 'ega_amount': echo esc_html(get_post_meta($id, 'ega_investment_amount', true)); break;
        case 'ega_roi': echo esc_html(get_post_meta($id, 'ega_target_roi', true)); break;
        case 'ega_status_col': echo esc_html(get_post_meta($id, 'ega_status', true)); break;
    }
}, 10, 2);

/* =========================================
   WIDGETS
   ========================================= */
add_action('widgets_init', function () {
    register_sidebar([
        'name' => __('Footer Column 1', 'ega'),
        'id' => 'footer-1',
        'before_widget' => '<div class="ega-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="eyebrow" style="color:var(--petrol-400);margin-bottom:20px;">',
        'after_title' => '</h4>',
    ]);
});

/* =========================================
   DISABLE COMMENTS ON CUSTOM TYPES
   ========================================= */
add_filter('comments_open', function ($open, $post_id) {
    $type = get_post_type($post_id);
    if (in_array($type, ['ega_opportunity', 'ega_insight', 'ega_enquiry', 'ega_appointment'])) return false;
    return $open;
}, 10, 2);

/* =========================================
   EXCERPT LENGTH
   ========================================= */
add_filter('excerpt_length', function () { return 30; });
add_filter('excerpt_more', function () { return '…'; });

/* =========================================
   INCLUDE TEMPLATE PARTS
   ========================================= */
require_once EGA_DIR . '/inc/data.php';
