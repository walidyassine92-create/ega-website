<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="<?php echo esc_url(EGA_URI . '/assets/images/favicon.svg'); ?>" type="image/svg+xml">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
$nav_items = [
    ['label' => __('About', 'ega'), 'slug' => 'about'],
    ['label' => __('Services', 'ega'), 'slug' => 'services'],
    ['label' => __('Opportunities', 'ega'), 'slug' => 'opportunities'],
    ['label' => __('Why Central Africa', 'ega'), 'slug' => 'why-central-africa'],
    ['label' => __('Sectors', 'ega'), 'slug' => 'sectors'],
    ['label' => __('Process', 'ega'), 'slug' => 'process'],
    ['label' => __('Insights', 'ega'), 'slug' => 'insights'],
];
$current_slug = basename(get_permalink());
$lang = ega_locale();
$lang_flags = ['en' => '🇬🇧', 'fr' => '🇫🇷', 'de' => '🇩🇪'];
$lang_names = ['en' => 'English', 'fr' => 'Français', 'de' => 'Deutsch'];
?>

<header class="ega-header" role="banner">
    <div class="ega-header-inner">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="ega-logo" aria-label="EGA Home">
            <svg viewBox="0 0 120 120" class="ega-compass" fill="none">
                <g><circle cx="60" cy="60" r="46" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" stroke-dasharray="2 7"/>
                <path d="M60 10 L67 53 L60 60 L53 53 Z" fill="currentColor"/>
                <path d="M60 110 L53 67 L60 60 L67 67 Z" fill="currentColor" opacity="0.7"/>
                <path d="M10 60 L53 53 L60 60 L53 67 Z" fill="currentColor" opacity="0.55"/>
                <path d="M110 60 L67 67 L60 60 L67 53 Z" fill="currentColor" opacity="0.55"/></g>
                <path d="M22 92 L48 66 L62 78 L92 40" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M78 40 L92 40 L92 54" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <div class="ega-logo-text">
                <strong>EGA</strong>
                <span>Equatorial Gateway Advisory</span>
            </div>
        </a>

        <nav class="ega-nav-links" aria-label="<?php esc_attr_e('Main Navigation', 'ega'); ?>">
            <?php foreach ($nav_items as $item) :
                $url = home_url('/' . $item['slug'] . '/');
                $active = ($current_slug === $item['slug']) ? ' active' : '';
            ?>
                <a href="<?php echo esc_url($url); ?>" class="link-underline<?php echo $active; ?>"><?php echo esc_html($item['label']); ?></a>
            <?php endforeach; ?>
        </nav>

        <div class="ega-nav-actions">
            <!-- Language -->
            <div style="position:relative;">
                <button class="ega-lang-btn" id="ega-lang-toggle" aria-label="<?php esc_attr_e('Language', 'ega'); ?>">
                    <span><?php echo $lang_flags[$lang] ?? '🇬🇧'; ?></span>
                    <span style="text-transform:uppercase;"><?php echo esc_html($lang); ?></span>
                    <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1 3l4 4 4-4" stroke="currentColor" stroke-width="1.4" fill="none"/></svg>
                </button>
                <div class="ega-lang-dropdown glass" id="ega-lang-dropdown">
                    <?php foreach (['en', 'fr', 'de'] as $l) :
                        $lang_url = '#';
                        if (function_exists('pll_the_languages')) {
                            // Polylang: get translated URL
                            $translations = pll_the_languages(['raw' => 1]);
                            if (isset($translations[$l])) $lang_url = $translations[$l]['url'];
                        }
                        $is_active = ($l === $lang) ? ' active' : '';
                    ?>
                        <a href="<?php echo esc_url($lang_url); ?>" class="<?php echo $is_active; ?>">
                            <span><?php echo $lang_flags[$l]; ?></span>
                            <span style="font-weight:500;"><?php echo esc_html($lang_names[$l]); ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Theme toggle -->
            <button class="ega-icon-btn" id="ega-theme-toggle" aria-label="<?php esc_attr_e('Toggle dark mode', 'ega'); ?>">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                    <circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>
                </svg>
            </button>

            <!-- CTA (desktop) -->
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="ega-btn-primary" style="display:none;">
                <?php esc_html_e('Schedule a Meeting', 'ega'); ?>
            </a>
            <style>@media (min-width:1024px) { .ega-nav-actions .ega-btn-primary { display: inline-flex !important; } }</style>

            <!-- Mobile menu button -->
            <button class="ega-icon-btn" id="ega-menu-open" aria-label="<?php esc_attr_e('Open menu', 'ega'); ?>" style="display:flex;">
                <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
            </button>
            <style>@media (min-width:1280px) { #ega-menu-open { display: none !important; } }</style>
        </div>
    </div>
</header>

<!-- Mobile overlay -->
<div class="ega-mobile-overlay" id="ega-mobile-overlay">
    <div class="ega-mobile-bg"></div>
    <div class="ega-mobile-panel">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:32px;">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="ega-logo">
                <svg viewBox="0 0 120 120" class="ega-compass" fill="none">
                    <g><path d="M60 10 L67 53 L60 60 L53 53 Z" fill="currentColor"/><path d="M60 110 L53 67 L60 60 L67 67 Z" fill="currentColor" opacity="0.7"/></g>
                    <path d="M22 92 L48 66 L62 78 L92 40" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M78 40 L92 40 L92 54" stroke="var(--ember-500)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div class="ega-logo-text"><strong>EGA</strong></div>
            </a>
            <button class="ega-icon-btn" id="ega-menu-close" aria-label="<?php esc_attr_e('Close menu', 'ega'); ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
            </button>
        </div>
        <nav class="ega-mobile-nav">
            <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'ega'); ?></a>
            <?php foreach ($nav_items as $item) : ?>
                <a href="<?php echo esc_url(home_url('/' . $item['slug'] . '/')); ?>"><?php echo esc_html($item['label']); ?></a>
            <?php endforeach; ?>
            <a href="<?php echo esc_url(home_url('/portal/')); ?>" class="ember"><?php esc_html_e('Investor Portal', 'ega'); ?></a>
        </nav>
        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="ega-btn-ember" style="margin-top:32px;text-align:center;">
            <?php esc_html_e('Schedule a Meeting', 'ega'); ?>
        </a>
        <div style="margin-top:auto;padding-top:32px;display:flex;gap:8px;">
            <?php foreach (['en', 'fr', 'de'] as $l) : ?>
                <a href="#" style="flex:1;text-align:center;padding:10px;border-radius:12px;border:1px solid var(--line);font-size:14px;font-weight:600;<?php echo ($l === $lang) ? 'border-color:var(--ember-400);color:var(--ember-500);' : ''; ?>">
                    <?php echo $lang_flags[$l] . ' ' . strtoupper($l); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<main id="main" role="main">
