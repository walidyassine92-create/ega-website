<?php
/**
 * EGA Static Data
 * Sectors, Countries, Process Steps, Stats — used in templates.
 * @package ega
 */

defined('ABSPATH') || exit;

function ega_sectors(): array {
    $uri = EGA_URI . '/assets/images/';
    return [
        ['id' => 'oil-gas', 'icon' => '⛽', 'image' => $uri . 'energy.jpg', 'name' => __('Oil & Gas', 'ega'), 'blurb' => __('Upstream, midstream and local value-addition across mature and frontier basins.', 'ega')],
        ['id' => 'mining', 'icon' => '⛏️', 'image' => $uri . 'mining.jpg', 'name' => __('Mining', 'ega'), 'blurb' => __('Iron, potash, copper and critical minerals for the energy transition.', 'ega')],
        ['id' => 'infrastructure', 'icon' => '🏗️', 'image' => $uri . 'infrastructure.jpg', 'name' => __('Infrastructure', 'ega'), 'blurb' => __('Roads, ports, bridges and urban systems underpinning regional trade.', 'ega')],
        ['id' => 'energy', 'icon' => '⚡', 'image' => $uri . 'energy.jpg', 'name' => __('Energy', 'ega'), 'blurb' => __('Hydropower, gas-to-power and solar closing the regional energy gap.', 'ega')],
        ['id' => 'agriculture', 'icon' => '🌾', 'image' => $uri . 'agriculture.jpg', 'name' => __('Agriculture', 'ega'), 'blurb' => __('Agro-industrial value chains turning fertile land into food security.', 'ega')],
        ['id' => 'forestry', 'icon' => '🌳', 'image' => $uri . 'sectors.jpg', 'name' => __('Forestry', 'ega'), 'blurb' => __('Certified, sustainable timber and carbon-economy opportunities.', 'ega')],
        ['id' => 'logistics', 'icon' => '🚢', 'image' => $uri . 'logistics.jpg', 'name' => __('Logistics', 'ega'), 'blurb' => __('Corridors, free zones and cold chains connecting the interior to ports.', 'ega')],
        ['id' => 'digital', 'icon' => '📡', 'image' => $uri . 'digital.jpg', 'name' => __('Digital', 'ega'), 'blurb' => __('Connectivity, data centres and fintech for a young, online population.', 'ega')],
        ['id' => 'real-estate', 'icon' => '🏢', 'image' => '', 'name' => __('Real Estate', 'ega'), 'blurb' => __('Residential, commercial and mixed-use in fast-urbanising cities.', 'ega')],
        ['id' => 'healthcare', 'icon' => '🏥', 'image' => '', 'name' => __('Healthcare', 'ega'), 'blurb' => __('Hospitals, diagnostics and pharma supply for rising demand.', 'ega')],
        ['id' => 'tourism', 'icon' => '🌍', 'image' => '', 'name' => __('Tourism', 'ega'), 'blurb' => __('Eco-tourism and hospitality built on extraordinary natural assets.', 'ega')],
        ['id' => 'manufacturing', 'icon' => '🏭', 'image' => '', 'name' => __('Manufacturing', 'ega'), 'blurb' => __('Import-substitution and export industries within special economic zones.', 'ega')],
    ];
}

function ega_countries(): array {
    return [
        ['id' => 'congo', 'flag' => '🇨🇬', 'name' => __('Republic of Congo', 'ega'), 'capital' => 'Brazzaville', 'tagline' => __('Our home market and regional gateway.', 'ega'), 'highlights' => __('Oil, timber, special economic zones and the Pointe-Noire deep-water port.', 'ega'), 'gdp' => '$15B', 'pop' => '6.1M', 'bar' => 78],
        ['id' => 'cameroon', 'flag' => '🇨🇲', 'name' => __('Cameroon', 'ega'), 'capital' => 'Yaoundé', 'tagline' => __("Central Africa's most diversified economy.", 'ega'), 'highlights' => __('Agriculture, the Kribi deep-sea port and a large consumer market.', 'ega'), 'gdp' => '$45B', 'pop' => '28M', 'bar' => 64],
        ['id' => 'gabon', 'flag' => '🇬🇦', 'name' => __('Gabon', 'ega'), 'capital' => 'Libreville', 'tagline' => __('A leader in sustainable forestry and manganese.', 'ega'), 'highlights' => __('High per-capita income, manganese, timber and carbon credits.', 'ega'), 'gdp' => '$20B', 'pop' => '2.4M', 'bar' => 52],
        ['id' => 'drc', 'flag' => '🇨🇩', 'name' => __('DR Congo', 'ega'), 'capital' => 'Kinshasa', 'tagline' => __("The world's critical-minerals powerhouse.", 'ega'), 'highlights' => __('Cobalt, copper, vast hydropower potential and a 100M+ market.', 'ega'), 'gdp' => '$67B', 'pop' => '102M', 'bar' => 88],
        ['id' => 'eq-guinea', 'flag' => '🇬🇶', 'name' => __('Equatorial Guinea', 'ega'), 'capital' => 'Malabo', 'tagline' => __('Hydrocarbons and emerging LNG hub.', 'ega'), 'highlights' => __('Oil, gas, LNG monetisation and downstream diversification.', 'ega'), 'gdp' => '$12B', 'pop' => '1.7M', 'bar' => 46],
        ['id' => 'chad', 'flag' => '🇹🇩', 'name' => __('Chad', 'ega'), 'capital' => "N'Djamena", 'tagline' => __('Oil, agriculture and Sahel connectivity.', 'ega'), 'highlights' => __('Petroleum, livestock value chains and solar energy potential.', 'ega'), 'gdp' => '$18B', 'pop' => '17M', 'bar' => 71],
        ['id' => 'car', 'flag' => '🇨🇫', 'name' => __('Central African Republic', 'ega'), 'capital' => 'Bangui', 'tagline' => __('Untapped resources and reconstruction.', 'ega'), 'highlights' => __('Diamonds, gold, timber and agricultural land at scale.', 'ega'), 'gdp' => '$2.4B', 'pop' => '5.5M', 'bar' => 28],
        ['id' => 'angola', 'flag' => '🇦🇴', 'name' => __('Angola', 'ega'), 'capital' => 'Luanda', 'tagline' => __('A reforming economy diversifying beyond oil.', 'ega'), 'highlights' => __('Oil, diamonds, agriculture and an ambitious privatisation agenda.', 'ega'), 'gdp' => '$107B', 'pop' => '36M', 'bar' => 92],
    ];
}

function ega_process_steps(): array {
    return [
        ['n' => '01', 'title' => __('Discovery', 'ega'), 'text' => __('We listen first — mapping your mandate, return targets, risk tolerance and strategic intent.', 'ega')],
        ['n' => '02', 'title' => __('Evaluation', 'ega'), 'text' => __('We screen markets and opportunities against your thesis, surfacing only credible, executable options.', 'ega')],
        ['n' => '03', 'title' => __('Due Diligence', 'ega'), 'text' => __('Commercial, legal, financial and reputational verification — no assumption goes unchecked.', 'ega')],
        ['n' => '04', 'title' => __('Government Coordination', 'ega'), 'text' => __('We align ministries, regulators and agencies to secure the approvals your project requires.', 'ega')],
        ['n' => '05', 'title' => __('Partner Matching', 'ega'), 'text' => __('We introduce trusted operators, co-investors and local partners with aligned incentives.', 'ega')],
        ['n' => '06', 'title' => __('Negotiation', 'ega'), 'text' => __('We structure and negotiate terms that protect your capital and the long-term relationship.', 'ega')],
        ['n' => '07', 'title' => __('Implementation', 'ega'), 'text' => __('We coordinate execution on the ground until capital is deployed and milestones are met.', 'ega')],
        ['n' => '08', 'title' => __('Monitoring', 'ega'), 'text' => __('We track performance and governance, protecting value across the life of the investment.', 'ega')],
    ];
}

function ega_stats(): array {
    return [
        ['value' => 8, 'prefix' => '', 'suffix' => '', 'decimals' => 0, 'label' => __('Markets covered across Central Africa', 'ega')],
        ['value' => 4.2, 'prefix' => '$', 'suffix' => 'B+', 'decimals' => 1, 'label' => __('Investment value advised & facilitated', 'ega')],
        ['value' => 12, 'prefix' => '', 'suffix' => '', 'decimals' => 0, 'label' => __('Priority sectors under active mandate', 'ega')],
        ['value' => 30, 'prefix' => '', 'suffix' => '+', 'decimals' => 0, 'label' => __('Years of combined regional leadership', 'ega')],
    ];
}

function ega_services(): array {
    return [
        ['title' => __('Investment Advisory', 'ega'), 'text' => __('Strategic counsel on entry, allocation and risk, grounded in real regional intelligence.', 'ega')],
        ['title' => __('Business Matching', 'ega'), 'text' => __('Precision introductions between investors, operators and project owners with aligned mandates.', 'ega')],
        ['title' => __('Market Entry Strategy', 'ega'), 'text' => __('Sequenced playbooks for establishing a credible, compliant footprint in new markets.', 'ega')],
        ['title' => __('Government Relations', 'ega'), 'text' => __('Trusted engagement with ministries, agencies and regulators at the highest level.', 'ega')],
        ['title' => __('Public-Private Partnerships', 'ega'), 'text' => __('Structuring PPPs that align public mandate with private return and bankability.', 'ega')],
        ['title' => __('Project Structuring', 'ega'), 'text' => __('Financial, legal and operational architecture designed for investability.', 'ega')],
        ['title' => __('Investment Facilitation', 'ega'), 'text' => __('Hands-on coordination to convert commitment into capital deployed on the ground.', 'ega')],
        ['title' => __('Strategic Intelligence', 'ega'), 'text' => __('Confidential reads on counterparties, markets and political economy.', 'ega')],
        ['title' => __('Due Diligence', 'ega'), 'text' => __('Rigorous commercial, legal and reputational verification before you commit.', 'ega')],
        ['title' => __('Administrative Support', 'ega'), 'text' => __('Licensing, permitting and the operational scaffolding that keeps deals moving.', 'ega')],
        ['title' => __('Investment Missions', 'ega'), 'text' => __('Curated on-the-ground missions connecting principals with decision-makers.', 'ega')],
        ['title' => __('Executive Advisory', 'ega'), 'text' => __('Board-level counsel for leaders navigating complex frontier decisions.', 'ega')],
    ];
}

function ega_why_pillars(): array {
    return [
        ['title' => __('Resource depth', 'ega'), 'text' => __("Among the richest endowments of oil, gas, minerals and timber on the continent — increasingly paired with value-addition mandates.", 'ega')],
        ['title' => __('Strategic geography', 'ega'), 'text' => __('Atlantic ports and river corridors positioning the region as a logistics gateway between Africa and global markets.', 'ega')],
        ['title' => __('Reform momentum', 'ega'), 'text' => __('Investment codes, special economic zones and regional integration lowering the cost of credible entry.', 'ega')],
        ['title' => __('Demographic dividend', 'ega'), 'text' => __('A young, urbanising population driving demand across energy, housing, healthcare and digital services.', 'ega')],
    ];
}
