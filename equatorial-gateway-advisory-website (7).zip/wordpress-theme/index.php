<?php
/**
 * Default Index / Blog
 * @package ega
 */
get_header();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Blog', 'ega'), 'title' => __('Latest updates', 'ega'), 'lead' => '']); ?>

<section class="ega-section">
    <div class="ega-container">
        <?php if (have_posts()) : ?>
            <div class="ega-grid-3">
                <?php while (have_posts()) : the_post(); ?>
                    <a href="<?php the_permalink(); ?>" class="ega-card lift reveal">
                        <h3><?php the_title(); ?></h3>
                        <p style="margin-top:12px;font-size:14px;line-height:1.7;"><?php the_excerpt(); ?></p>
                        <span style="margin-top:16px;font-size:12px;color:var(--slatey-400);"><?php echo get_the_date(); ?></span>
                    </a>
                <?php endwhile; ?>
            </div>
            <div style="margin-top:48px;text-align:center;">
                <?php the_posts_pagination(); ?>
            </div>
        <?php else : ?>
            <p style="text-align:center;padding:64px 0;"><?php esc_html_e('No posts found.', 'ega'); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
