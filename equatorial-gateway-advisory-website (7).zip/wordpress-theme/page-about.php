<?php
/**
 * Template Name: About
 * @package ega
 */
get_header();
$stats = ega_stats();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Who we are', 'ega'), 'title' => __('A trusted bridge between international capital and African opportunity.', 'ega'), 'lead' => __('EGA exists to make Central Africa investable with confidence. We sit at the intersection of governments, investors and operators, translating ambition into structured, executable transactions.', 'ega'), 'image' => EGA_URI . '/assets/images/hero.jpg']); ?>

<section class="ega-section">
    <div class="ega-container">
        <div class="ega-about-grid">
            <div class="reveal">
                <div class="ega-about-image">
                    <img src="<?php echo esc_url(EGA_URI . '/assets/images/infrastructure.jpg'); ?>" alt="<?php esc_attr_e('Infrastructure in Central Africa', 'ega'); ?>" loading="lazy">
                </div>
            </div>
            <div>
                <p class="reveal" style="font-family:var(--font-serif);font-size:clamp(1.25rem,2vw,1.75rem);font-style:italic;line-height:1.5;color:var(--petrol-900);"><?php esc_html_e('From sovereign funds and private equity to family offices and strategic corporates, we give principals privileged access, rigorous diligence and the institutional relationships required to move from interest to capital deployed. Our work is discreet, our standards are global, and our presence is local.', 'ega'); ?></p>
                <div style="margin-top:40px;">
                    <?php foreach ([
                        [__('Access', 'ega'), __('Direct relationships with ministries, agencies and project owners across the region.', 'ega')],
                        [__('Intelligence', 'ega'), __('Ground-truth market reading that no desk in London or Dubai can replicate.', 'ega')],
                        [__('Execution', 'ega'), __('We stay until capital is deployed and milestones are met — not just introduced.', 'ega')],
                    ] as $pt) : ?>
                        <div class="reveal" style="display:flex;gap:20px;margin-bottom:24px;">
                            <span style="margin-top:4px;display:block;width:4px;min-height:40px;border-radius:9999px;background:var(--ember-500);flex-shrink:0;"></span>
                            <div>
                                <h3 style="font-family:var(--font-display);font-size:18px;font-weight:700;color:var(--petrol-900);"><?php echo esc_html($pt[0]); ?></h3>
                                <p style="margin-top:6px;font-size:14px;line-height:1.7;color:var(--slatey-600);"><?php echo esc_html($pt[1]); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Photo gallery -->
<section style="overflow:hidden;padding:64px 0;background:var(--bg-soft);">
    <div class="ega-container reveal">
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;">
            <?php
            $gallery = [
                ['src' => EGA_URI . '/assets/images/energy.jpg', 'alt' => __('Energy infrastructure', 'ega')],
                ['src' => EGA_URI . '/assets/images/mining.jpg', 'alt' => __('Mining operations', 'ega')],
                ['src' => EGA_URI . '/assets/images/agriculture.jpg', 'alt' => __('Agricultural landscapes', 'ega')],
                ['src' => EGA_URI . '/assets/images/logistics.jpg', 'alt' => __('Port logistics', 'ega')],
            ];
            foreach ($gallery as $img) : ?>
                <div style="position:relative;aspect-ratio:4/3;overflow:hidden;border-radius:16px;">
                    <img src="<?php echo esc_url($img['src']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform 0.7s cubic-bezier(0.16,1,0.3,1);">
                    <div style="position:absolute;inset:0;background:rgba(4,18,27,0.2);transition:opacity 0.5s;"></div>
                </div>
            <?php endforeach; ?>
        </div>
        <style>@media(min-width:768px){.ega-container .reveal > div{grid-template-columns:repeat(4,1fr)!important;}}</style>
    </div>
</section>

<section class="ega-section-petrol ega-section">
    <div class="grid-veil"></div>
    <div class="ega-container" style="position:relative;">
        <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('By the numbers', 'ega'), 'title' => __('Scale, reach and rigour.', 'ega'), 'light' => true]); ?>
        <div class="ega-stats">
            <?php foreach ($stats as $s) : ?>
                <div class="ega-stat reveal">
                    <p class="number"><span data-counter="<?php echo esc_attr($s['value']); ?>" data-prefix="<?php echo esc_attr($s['prefix']); ?>" data-suffix="<?php echo esc_attr($s['suffix']); ?>" data-decimals="<?php echo esc_attr($s['decimals']); ?>">0</span></p>
                    <p class="label"><?php echo esc_html($s['label']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
