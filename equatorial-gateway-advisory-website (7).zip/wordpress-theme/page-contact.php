<?php
/**
 * Template Name: Contact
 * @package ega
 */
get_header();
$email = get_theme_mod('ega_email', 'contact@equatorialgatewayadvisory.com');
$offices = get_theme_mod('ega_offices', 'Brazzaville · Pointe-Noire · Regional Central Africa');
$engagement = get_theme_mod('ega_engagement', 'By appointment — globally, in confidence');
$sectors = ega_sectors();
$budgets = [__('Under $1M', 'ega'), __('$1M – $10M', 'ega'), __('$10M – $50M', 'ega'), __('$50M – $250M', 'ega'), __('$250M+', 'ega')];
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Contact', 'ega'), 'title' => __('Begin a confidential conversation.', 'ega'), 'lead' => __('Tell us about your mandate. A senior advisor will respond personally and in confidence.', 'ega')]); ?>

<section class="ega-section">
    <div class="ega-container">
        <div style="display:grid;gap:48px;" class="ega-contact-layout">
            <style>@media (min-width:1024px) { .ega-contact-layout { grid-template-columns: 1fr 1.3fr; } }</style>

            <!-- Left: details + appointment -->
            <div>
                <div class="reveal" style="margin-bottom:32px;">
                    <div class="ega-contact-detail" style="margin-bottom:32px;">
                        <p class="eyebrow label"><?php esc_html_e('Email', 'ega'); ?></p>
                        <a href="mailto:<?php echo esc_attr($email); ?>" class="link-underline value"><?php echo esc_html($email); ?></a>
                    </div>
                    <div class="ega-contact-detail" style="margin-bottom:32px;">
                        <p class="eyebrow label"><?php esc_html_e('Presence', 'ega'); ?></p>
                        <p class="value"><?php echo esc_html($offices); ?></p>
                    </div>
                    <div class="ega-contact-detail">
                        <p class="eyebrow label"><?php esc_html_e('Engagement', 'ega'); ?></p>
                        <p class="value"><?php echo esc_html($engagement); ?></p>
                    </div>
                </div>

                <!-- Appointment form -->
                <div class="ega-form-card reveal" data-delay="0.1">
                    <h3 style="font-family:var(--font-display);font-size:1.25rem;font-weight:700;"><?php esc_html_e('Book an appointment', 'ega'); ?></h3>
                    <p style="margin-top:8px;font-size:14px;color:var(--slatey-600);"><?php esc_html_e('Reserve a confidential session with our advisory team.', 'ega'); ?></p>
                    <form id="ega-appointment-form" style="margin-top:24px;">
                        <div class="ega-form-grid">
                            <div><label class="ega-label" for="ap-name"><?php esc_html_e('Full name', 'ega'); ?> *</label><input id="ap-name" name="name" required class="ega-input"></div>
                            <div><label class="ega-label" for="ap-email"><?php esc_html_e('Email', 'ega'); ?> *</label><input id="ap-email" name="email" type="email" required class="ega-input"></div>
                            <div><label class="ega-label" for="ap-org"><?php esc_html_e('Organisation', 'ega'); ?></label><input id="ap-org" name="organisation" class="ega-input"></div>
                            <div><label class="ega-label" for="ap-date"><?php esc_html_e('Preferred date', 'ega'); ?></label><input id="ap-date" name="preferredDate" type="date" class="ega-input"></div>
                            <div class="full"><label class="ega-label" for="ap-topic"><?php esc_html_e('Topic', 'ega'); ?></label><input id="ap-topic" name="topic" class="ega-input"></div>
                            <div class="full"><label class="ega-label" for="ap-notes"><?php esc_html_e('Notes', 'ega'); ?></label><textarea id="ap-notes" name="notes" rows="3" class="ega-textarea"></textarea></div>
                        </div>
                        <p id="ega-appt-status" style="margin-top:12px;font-size:14px;"></p>
                        <button type="submit" class="ega-btn-primary" style="margin-top:20px;width:100%;" data-success="<?php esc_attr_e('Request received. We will confirm your appointment by email.', 'ega'); ?>"><?php esc_html_e('Request appointment', 'ega'); ?></button>
                    </form>
                </div>
            </div>

            <!-- Right: contact form -->
            <div class="reveal" data-delay="0.05">
                <form id="ega-contact-form" class="ega-form-card">
                    <div class="ega-form-grid">
                        <div><label class="ega-label" for="cf-name"><?php esc_html_e('Full name', 'ega'); ?> *</label><input id="cf-name" name="name" required class="ega-input" autocomplete="name"></div>
                        <div><label class="ega-label" for="cf-company"><?php esc_html_e('Company / Institution', 'ega'); ?></label><input id="cf-company" name="company" class="ega-input" autocomplete="organization"></div>
                        <div><label class="ega-label" for="cf-country"><?php esc_html_e('Country', 'ega'); ?></label><input id="cf-country" name="country" class="ega-input" autocomplete="country-name"></div>
                        <div><label class="ega-label" for="cf-phone"><?php esc_html_e('Phone', 'ega'); ?></label><input id="cf-phone" name="phone" type="tel" class="ega-input" autocomplete="tel"></div>
                        <div><label class="ega-label" for="cf-email"><?php esc_html_e('Email', 'ega'); ?> *</label><input id="cf-email" name="email" type="email" required class="ega-input" autocomplete="email"></div>
                        <div>
                            <label class="ega-label" for="cf-sector"><?php esc_html_e('Investment sector', 'ega'); ?></label>
                            <select id="cf-sector" name="sector" class="ega-select">
                                <option value="" disabled selected><?php esc_html_e('Select a sector', 'ega'); ?></option>
                                <?php foreach ($sectors as $s) : ?>
                                    <option value="<?php echo esc_attr($s['name']); ?>"><?php echo esc_html($s['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="full">
                            <label class="ega-label" for="cf-budget"><?php esc_html_e('Estimated budget', 'ega'); ?></label>
                            <select id="cf-budget" name="budget" class="ega-select">
                                <option value="" disabled selected><?php esc_html_e('Select a range', 'ega'); ?></option>
                                <?php foreach ($budgets as $b) : ?>
                                    <option value="<?php echo esc_attr($b); ?>"><?php echo esc_html($b); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="full">
                            <label class="ega-label" for="cf-message"><?php esc_html_e('Message', 'ega'); ?> *</label>
                            <textarea id="cf-message" name="message" required rows="4" class="ega-textarea"></textarea>
                        </div>
                    </div>
                    <p id="ega-form-status" style="margin-top:12px;font-size:14px;"></p>
                    <button type="submit" class="ega-btn-ember" style="margin-top:24px;width:100%;"
                        data-label="<?php esc_attr_e('Send enquiry', 'ega'); ?>"
                        data-sending="<?php esc_attr_e('Sending…', 'ega'); ?>"
                        data-success="<?php esc_attr_e('Thank you. A senior advisor will be in touch shortly.', 'ega'); ?>"
                        data-error="<?php esc_attr_e('Something went wrong. Please try again or email us directly.', 'ega'); ?>">
                        <?php esc_html_e('Send enquiry', 'ega'); ?>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
