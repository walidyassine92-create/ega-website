<?php
/**
 * Template Name: Investor Portal
 * @package ega
 */
get_header();
$countries = ega_countries();
$features = [
    [__('Private data room', 'ega'), __('Confidential financials, legal packs and project documentation per mandate.', 'ega')],
    [__('Economic dashboard', 'ega'), __('Macro indicators and sector signals refreshed across our coverage markets.', 'ega')],
    [__('Deal monitoring', 'ega'), __('Milestone tracking from structuring through to capital deployment.', 'ega')],
];
?>

<section class="ega-section-dark" style="padding:144px 0 112px;">
    <div class="grid-veil" style="opacity:0.15;"></div>
    <div style="position:absolute;right:-128px;top:0;width:420px;height:420px;border-radius:50%;background:rgba(200,83,31,0.15);filter:blur(130px);pointer-events:none;"></div>
    <div class="ega-container" style="position:relative;">
        <div class="reveal">
            <div class="ega-heading-eyebrow"><span class="line"></span><span class="eyebrow" style="color:var(--ember-300);"><?php esc_html_e('Investor Portal', 'ega'); ?></span></div>
        </div>
        <h1 class="reveal" data-delay="0.05" style="max-width:768px;font-size:clamp(2rem,5vw,3.5rem);color:#fff;"><?php esc_html_e('Secure access for qualified investors.', 'ega'); ?></h1>
        <p class="reveal" data-delay="0.1" style="margin-top:24px;max-width:640px;font-size:clamp(1rem,1.5vw,1.125rem);line-height:1.7;color:var(--petrol-200);"><?php esc_html_e('The EGA Investor Portal provides verified principals with private data rooms, an economic dashboard and live deal monitoring.', 'ega'); ?></p>

        <div style="margin-top:64px;display:grid;gap:40px;" class="ega-portal-layout">
            <style>@media (min-width:1024px) { .ega-portal-layout { grid-template-columns: 1.2fr 1fr; } }</style>

            <!-- Dashboard preview -->
            <div class="ega-portal-card reveal">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="width:28px;height:28px;border-radius:8px;background:rgba(200,83,31,0.2);color:var(--ember-300);display:flex;align-items:center;justify-content:center;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18M7 14l4-4 4 4 5-6"/></svg>
                        </span>
                        <p style="font-family:var(--font-display);font-size:14px;font-weight:700;"><?php echo esc_html($features[1][0]); ?></p>
                    </div>
                    <span style="padding:4px 10px;border-radius:9999px;background:rgba(16,185,129,0.15);font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:rgb(110,231,183);">Live</span>
                </div>
                <?php foreach (array_slice($countries, 0, 6) as $i => $c) :
                    $widths = [78, 64, 52, 88, 46, 71];
                    $w = $widths[$i] ?? 50;
                ?>
                    <div style="margin-bottom:16px;">
                        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px;">
                            <span style="color:var(--petrol-200);"><?php echo $c['flag'] . ' ' . esc_html($c['name']); ?></span>
                            <span style="font-weight:600;color:#fff;"><?php echo esc_html($c['gdp']); ?></span>
                        </div>
                        <div class="ega-portal-bar">
                            <div class="ega-portal-bar-fill" data-width="<?php echo $w; ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:24px;padding-top:24px;border-top:1px solid rgba(255,255,255,0.1);text-align:center;">
                    <div><p style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:#fff;">9</p><p style="font-size:10px;text-transform:uppercase;letter-spacing:0.12em;color:var(--petrol-300);">Active deals</p></div>
                    <div><p style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--ember-400);">$2.3B</p><p style="font-size:10px;text-transform:uppercase;letter-spacing:0.12em;color:var(--petrol-300);">In pipeline</p></div>
                    <div><p style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:#fff;">8</p><p style="font-size:10px;text-transform:uppercase;letter-spacing:0.12em;color:var(--petrol-300);">Markets</p></div>
                </div>
            </div>

            <!-- Access form -->
            <div class="ega-portal-card reveal" data-delay="0.1">
                <div style="display:flex;align-items:center;gap:8px;color:var(--ember-300);margin-bottom:20px;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    <h2 style="font-family:var(--font-display);font-size:18px;font-weight:700;color:#fff;"><?php esc_html_e('Request access', 'ega'); ?></h2>
                </div>
                <p style="margin-bottom:24px;font-size:14px;line-height:1.7;color:var(--petrol-200);"><?php esc_html_e('Access is granted to verified institutional investors. Submit your details and our team will arrange onboarding.', 'ega'); ?></p>
                <form id="ega-portal-form" onsubmit="event.preventDefault();this.style.display='none';document.getElementById('ega-portal-done').style.display='block';">
                    <div style="margin-bottom:16px;">
                        <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.12em;color:var(--petrol-300);"><?php esc_html_e('Institution / Investor ID', 'ega'); ?></label>
                        <input required style="width:100%;border-radius:12px;border:1px solid var(--petrol-700);background:rgba(7,24,36,0.5);padding:12px 16px;font-size:14px;color:#fff;outline:none;">
                    </div>
                    <div style="margin-bottom:16px;">
                        <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.12em;color:var(--petrol-300);"><?php esc_html_e('Work email', 'ega'); ?></label>
                        <input type="email" required style="width:100%;border-radius:12px;border:1px solid var(--petrol-700);background:rgba(7,24,36,0.5);padding:12px 16px;font-size:14px;color:#fff;outline:none;">
                    </div>
                    <button type="submit" class="ega-btn-ember" style="width:100%;"><?php esc_html_e('Request secure access', 'ega'); ?></button>
                </form>
                <div id="ega-portal-done" style="display:none;padding:24px;border-radius:16px;border:1px solid rgba(200,83,31,0.3);background:rgba(200,83,31,0.1);font-size:14px;line-height:1.7;color:var(--ember-100);">
                    <?php esc_html_e('Verified principals receive credentials via secure, out-of-band delivery.', 'ega'); ?>
                </div>
                <p style="margin-top:20px;font-size:12px;line-height:1.7;color:var(--petrol-400);"><?php esc_html_e('All access requests are reviewed under strict confidentiality and KYC procedures.', 'ega'); ?></p>
            </div>
        </div>

        <!-- Features -->
        <div style="margin-top:64px;display:grid;gap:20px;" class="ega-portal-features">
            <style>@media (min-width:768px) { .ega-portal-features { grid-template-columns: repeat(3, 1fr); } }</style>
            <?php foreach ($features as $f) : ?>
                <div class="reveal" style="padding:28px;border-radius:16px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.02);">
                    <p style="font-family:var(--font-display);font-size:18px;font-weight:700;color:#fff;"><?php echo esc_html($f[0]); ?></p>
                    <p style="margin-top:8px;font-size:14px;line-height:1.7;color:var(--petrol-200);"><?php echo esc_html($f[1]); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
