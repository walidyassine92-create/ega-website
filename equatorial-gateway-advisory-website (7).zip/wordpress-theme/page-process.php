<?php
/**
 * Template Name: Process
 * @package ega
 */
get_header();
$steps = ega_process_steps();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Process', 'ega'), 'title' => __('An eight-stage methodology.', 'ega'), 'lead' => __('Every engagement follows a disciplined path designed to de-risk capital and protect reputations at each step.', 'ega'), 'image' => EGA_URI . '/assets/images/infrastructure.jpg']); ?>

<section class="ega-section">
    <div class="ega-narrow">
        <div class="ega-timeline">
            <div class="ega-timeline-line"></div>
            <?php foreach ($steps as $step) : ?>
                <div class="ega-timeline-step reveal">
                    <div class="ega-timeline-dot"><?php echo esc_html($step['n']); ?></div>
                    <div class="ega-timeline-card lift">
                        <h3><?php echo esc_html($step['title']); ?></h3>
                        <p><?php echo esc_html($step['text']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
