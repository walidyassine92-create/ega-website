<?php
/**
 * Template Name: Sectors
 * @package ega
 */
get_header();
$sectors = ega_sectors();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Sectors', 'ega'), 'title' => __('Priority sectors.', 'ega'), 'lead' => __('Each sector is mapped to active mandates, credible counterparties and structured opportunities — not generalities.', 'ega'), 'image' => EGA_URI . '/assets/images/sectors.jpg']); ?>

<section class="ega-section" style="position:relative;">
    <div class="ega-container">
        <div class="ega-grid-3">
            <?php foreach ($sectors as $i => $s) : ?>
                <div id="<?php echo esc_attr($s['id']); ?>" class="ega-card lift reveal" style="scroll-margin-top:112px;padding:0;overflow:hidden;">
                    <?php if (!empty($s['image'])) : ?>
                        <div style="position:relative;height:180px;overflow:hidden;">
                            <img src="<?php echo esc_url($s['image']); ?>" alt="<?php echo esc_attr($s['name']); ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;transition:transform 0.7s cubic-bezier(0.16,1,0.3,1);">
                            <div style="position:absolute;inset:0;background:linear-gradient(to top,var(--card),transparent);"></div>
                            <span style="position:absolute;left:16px;top:16px;width:48px;height:48px;border-radius:16px;background:rgba(255,255,255,0.9);display:flex;align-items:center;justify-content:center;font-size:1.5rem;box-shadow:0 4px 16px rgba(0,0,0,0.15);"><?php echo $s['icon']; ?></span>
                        </div>
                    <?php else : ?>
                        <div style="padding:32px 28px 0;"><span style="font-size:2.5rem;"><?php echo $s['icon']; ?></span></div>
                    <?php endif; ?>
                    <div style="padding:<?php echo !empty($s['image']) ? '16px 28px 28px' : '16px 28px 28px'; ?>;">
                        <h2 style="font-size:1.5rem;"><?php echo esc_html($s['name']); ?></h2>
                        <p style="margin-top:12px;font-size:14px;line-height:1.7;"><?php echo esc_html($s['blurb']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
