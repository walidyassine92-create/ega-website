<?php
/**
 * Template Name: Services
 * @package ega
 */
get_header();
$services = ega_services();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Services', 'ega'), 'title' => __('Advisory across the full investment lifecycle.', 'ega'), 'lead' => __('End-to-end capabilities that take principals from market thesis to deployed capital and beyond — delivered with institutional rigour and absolute discretion.', 'ega'), 'image' => EGA_URI . '/assets/images/boardroom.jpg']); ?>

<section class="ega-section">
    <div class="ega-container">
        <div class="ega-services-grid">
            <?php foreach ($services as $i => $item) : ?>
                <div class="ega-service-item reveal">
                    <span class="number"><?php echo str_pad($i + 1, 2, '0', STR_PAD_LEFT); ?></span>
                    <h3><?php echo esc_html($item['title']); ?></h3>
                    <p><?php echo esc_html($item['text']); ?></p>
                    <span class="hover-bar"></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
