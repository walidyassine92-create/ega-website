<?php
/**
 * Template Name: Why Central Africa
 * @package ega
 */
get_header();
$pillars = ega_why_pillars();
$countries = ega_countries();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => __('Why Central Africa', 'ega'), 'title' => __('The strategic case for the region.', 'ega'), 'lead' => __("Central Africa holds some of the world's most significant untapped resources and a generation of reforming economies opening to disciplined foreign capital.", 'ega'), 'image' => EGA_URI . '/assets/images/agriculture.jpg']); ?>

<section class="ega-section">
    <div class="ega-container">
        <div class="ega-grid-2">
            <?php foreach ($pillars as $i => $p) : ?>
                <div class="ega-pillar-card lift reveal">
                    <span class="num"><?php echo str_pad($i + 1, 2, '0', STR_PAD_LEFT); ?></span>
                    <div>
                        <h3><?php echo esc_html($p['title']); ?></h3>
                        <p><?php echo esc_html($p['text']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ega-section ega-section-soft">
    <div class="ega-container">
        <?php get_template_part('template-parts/section-heading', null, ['eyebrow' => __('Why Central Africa', 'ega'), 'title' => __('Country profiles', 'ega')]); ?>
        <div class="ega-countries-grid" style="margin-top:56px;">
            <div>
                <div class="ega-country-buttons">
                    <?php foreach ($countries as $c) : ?>
                        <button class="ega-country-btn" data-country="<?php echo esc_attr($c['id']); ?>">
                            <span class="flag"><?php echo $c['flag']; ?></span>
                            <span class="name"><?php echo esc_html($c['name']); ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
            <div>
                <?php foreach ($countries as $c) : ?>
                    <div class="ega-country-panel ega-country-detail" data-country="<?php echo esc_attr($c['id']); ?>" style="display:none;">
                        <span class="bg-flag"><?php echo $c['flag']; ?></span>
                        <div class="header"><span class="flag"><?php echo $c['flag']; ?></span><div><h3><?php echo esc_html($c['name']); ?></h3><p class="capital"><?php echo esc_html($c['capital']); ?></p></div></div>
                        <p class="tagline"><?php echo esc_html($c['tagline']); ?></p>
                        <p class="highlights"><?php echo esc_html($c['highlights']); ?></p>
                        <div class="stats-row"><div><p class="val"><?php echo esc_html($c['gdp']); ?></p><p class="lbl">GDP</p></div><div><p class="val"><?php echo esc_html($c['pop']); ?></p><p class="lbl">Population</p></div></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
