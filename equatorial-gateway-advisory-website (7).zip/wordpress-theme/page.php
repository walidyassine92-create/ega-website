<?php
/**
 * Default Page Template
 * @package ega
 */
get_header();
?>

<?php get_template_part('template-parts/page-hero', null, ['eyebrow' => '', 'title' => get_the_title(), 'lead' => '']); ?>

<section class="ega-section">
    <div class="ega-container" style="max-width:768px;">
        <div class="ega-article-content" style="padding:0;">
            <?php the_content(); ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
