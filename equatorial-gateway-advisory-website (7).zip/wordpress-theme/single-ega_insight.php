<?php
/**
 * Single Insight Article
 * @package ega
 */
get_header();
$read_min = get_post_meta(get_the_ID(), 'ega_read_min', true) ?: 5;
$cats = get_the_terms(get_the_ID(), 'ega_insight_category');
$cat_name = ($cats && !is_wp_error($cats)) ? $cats[0]->name : __('Analysis', 'ega');
?>

<article>
    <div class="ega-page-hero">
        <div class="grid-veil" style="position:absolute;inset:0;opacity:0.2;pointer-events:none;"></div>
        <div class="ega-container" style="position:relative;max-width:768px;">
            <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="link-underline" style="display:inline-flex;align-items:center;gap:8px;margin-bottom:32px;font-size:14px;font-weight:500;color:var(--petrol-300);">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
                <?php esc_html_e('Insights', 'ega'); ?>
            </a>
            <div style="display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin-bottom:24px;font-size:12px;">
                <span style="padding:4px 12px;border-radius:9999px;background:rgba(200,83,31,0.15);font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:var(--ember-300);"><?php echo esc_html($cat_name); ?></span>
                <span style="color:var(--petrol-300);"><?php echo get_the_date(); ?></span>
                <span style="color:var(--petrol-300);">· <?php echo esc_html($read_min); ?> <?php esc_html_e('min read', 'ega'); ?></span>
            </div>
            <h1 style="font-size:clamp(1.8rem,4vw,3rem);"><?php the_title(); ?></h1>
        </div>
    </div>

    <div class="ega-article-content">
        <?php if (has_excerpt()) : ?>
            <p class="reveal" style="font-family:var(--font-serif);font-size:clamp(1.125rem,1.5vw,1.5rem);font-style:italic;line-height:1.6;color:var(--petrol-900);"><?php echo esc_html(get_the_excerpt()); ?></p>
        <?php endif; ?>
        <div class="reveal" data-delay="0.05">
            <?php the_content(); ?>
        </div>
        <div class="ega-article-cta reveal" data-delay="0.1">
            <p style="font-family:var(--font-display);font-size:18px;font-weight:700;color:var(--petrol-900);"><?php echo esc_html(ega_t('cta_title', 'Capital moves where trust leads.')); ?></p>
            <p style="margin-top:8px;font-size:14px;line-height:1.7;color:var(--slatey-600);"><?php echo esc_html(ega_t('cta_subtitle', 'Open a confidential dialogue with our advisory team and explore how EGA can structure your entry into Central Africa.')); ?></p>
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="ega-btn-ember" style="margin-top:20px;"><?php esc_html_e('Schedule a Meeting', 'ega'); ?></a>
        </div>
    </div>
</article>

<?php get_template_part('template-parts/cta-section'); ?>
<?php get_footer(); ?>
