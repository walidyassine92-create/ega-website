<?php
/**
 * CTA Section partial
 * @package ega
 */
?>
<section class="ega-section-dark ega-cta-section">
    <div class="grid-veil" style="opacity:0.2;"></div>
    <div class="ega-cta-glow"></div>
    <div class="ega-container" style="position:relative;">
        <div style="max-width:768px;margin:0 auto;">
            <div class="reveal" style="display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:20px;">
                <span style="display:block;width:36px;height:1px;background:var(--ember-500);"></span>
                <span class="eyebrow" style="color:var(--ember-300);"><?php echo esc_html(ega_t('cta_eyebrow', 'Begin the conversation')); ?></span>
                <span style="display:block;width:36px;height:1px;background:var(--ember-500);"></span>
            </div>
            <h2 class="reveal" data-delay="0.05" style="color:#fff;"><?php echo esc_html(ega_t('cta_title', 'Capital moves where trust leads.')); ?></h2>
            <p class="reveal" data-delay="0.1" style="margin:24px auto 0;max-width:580px;font-size:clamp(1rem,1.5vw,1.125rem);line-height:1.7;color:var(--petrol-200);"><?php echo esc_html(ega_t('cta_subtitle', 'Open a confidential dialogue with our advisory team and explore how EGA can structure your entry into Central Africa.')); ?></p>
            <div class="ega-cta-actions reveal" data-delay="0.15">
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="ega-btn-ember"><?php esc_html_e('Schedule a Meeting', 'ega'); ?></a>
                <a href="<?php echo esc_url(home_url('/portal/')); ?>" class="ega-btn-outline"><?php esc_html_e('Contact the team', 'ega'); ?></a>
            </div>
        </div>
    </div>
</section>
