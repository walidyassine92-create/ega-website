<?php
/**
 * Insight Card partial — with image header
 * @package ega
 */
$read_min = get_post_meta(get_the_ID(), 'ega_read_min', true) ?: 5;
$cats = get_the_terms(get_the_ID(), 'ega_insight_category');
$cat_name = ($cats && !is_wp_error($cats)) ? $cats[0]->name : __('Analysis', 'ega');
// Cycle through available images for visual interest
$insight_images = [
    EGA_URI . '/assets/images/boardroom.jpg',
    EGA_URI . '/assets/images/mining.jpg',
    EGA_URI . '/assets/images/infrastructure.jpg',
    EGA_URI . '/assets/images/logistics.jpg',
];
global $wp_query;
$idx = $wp_query->current_post ?? 0;
$img = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'ega-card') : $insight_images[$idx % count($insight_images)];
?>
<a href="<?php the_permalink(); ?>" class="ega-card ega-insight-card lift reveal" style="padding:0;overflow:hidden;">
    <div class="insight-image">
        <img src="<?php echo esc_url($img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
        <div style="position:absolute;inset:0;background:linear-gradient(to top,var(--card),rgba(255,255,255,0.2),transparent);"></div>
        <div style="position:absolute;bottom:12px;left:16px;right:16px;display:flex;align-items:center;justify-content:space-between;font-size:12px;">
            <span style="padding:4px 12px;border-radius:9999px;background:rgba(255,255,255,0.9);font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:var(--petrol-600);box-shadow:0 2px 8px rgba(0,0,0,0.1);backdrop-filter:blur(4px);"><?php echo esc_html($cat_name); ?></span>
            <span style="padding:4px 12px;border-radius:9999px;background:rgba(0,0,0,0.4);color:#fff;font-weight:500;backdrop-filter:blur(4px);"><?php echo esc_html($read_min); ?> <?php esc_html_e('min read', 'ega'); ?></span>
        </div>
    </div>
    <div style="padding:20px 24px 24px;">
        <h3 style="margin-top:0;"><?php the_title(); ?></h3>
        <p style="margin-top:12px;font-size:14px;line-height:1.7;flex:1;"><?php echo esc_html(get_the_excerpt()); ?></p>
        <span class="read-link" style="margin-top:20px;"><?php esc_html_e('Read analysis', 'ega'); ?> <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
    </div>
</a>
