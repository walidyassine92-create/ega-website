<?php
/**
 * Opportunity Card partial — with sector image header
 * @package ega
 */
$amount = get_post_meta(get_the_ID(), 'ega_investment_amount', true);
$roi = get_post_meta(get_the_ID(), 'ega_target_roi', true);
$status = get_post_meta(get_the_ID(), 'ega_status', true);
$sector_terms = get_the_terms(get_the_ID(), 'ega_sector');
$country_terms = get_the_terms(get_the_ID(), 'ega_country');
$sector_name = ($sector_terms && !is_wp_error($sector_terms)) ? $sector_terms[0]->name : '';
$sector_slug = ($sector_terms && !is_wp_error($sector_terms)) ? $sector_terms[0]->slug : '';
$country_name = ($country_terms && !is_wp_error($country_terms)) ? $country_terms[0]->name : '';

// Map sector slug to image
$sector_images = [
    'oil-gas' => 'energy.jpg',
    'mining' => 'mining.jpg',
    'infrastructure' => 'infrastructure.jpg',
    'energy' => 'energy.jpg',
    'agriculture' => 'agriculture.jpg',
    'forestry' => 'sectors.jpg',
    'logistics' => 'logistics.jpg',
    'digital' => 'digital.jpg',
];
$sector_icons = [
    'oil-gas' => '⛽', 'mining' => '⛏️', 'infrastructure' => '🏗️', 'energy' => '⚡',
    'agriculture' => '🌾', 'forestry' => '🌳', 'logistics' => '🚢', 'digital' => '📡',
    'real-estate' => '🏢', 'healthcare' => '🏥', 'tourism' => '🌍', 'manufacturing' => '🏭',
];
$sector_img = isset($sector_images[$sector_slug]) ? EGA_URI . '/assets/images/' . $sector_images[$sector_slug] : '';
$sector_icon = $sector_icons[$sector_slug] ?? '';
$has_thumbnail = has_post_thumbnail();
$opp_img = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'ega-card') : $sector_img;
?>
<div class="ega-card ega-opp-card lift reveal" style="padding:0;overflow:hidden;border-radius:24px;">
    <?php if ($opp_img) : ?>
        <div class="opp-image">
            <img src="<?php echo esc_url($opp_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
            <div style="position:absolute;inset:0;background:linear-gradient(to top,var(--card),rgba(255,255,255,0.4),transparent);"></div>
            <div style="position:absolute;bottom:12px;left:16px;right:16px;display:flex;align-items:center;justify-content:space-between;">
                <span style="display:flex;align-items:center;gap:6px;padding:4px 12px;border-radius:9999px;background:rgba(255,255,255,0.9);font-size:12px;font-weight:600;color:var(--petrol-800);box-shadow:0 2px 8px rgba(0,0,0,0.1);backdrop-filter:blur(4px);">
                    <?php if ($sector_icon) echo '<span>' . $sector_icon . '</span>'; ?>
                    <?php echo esc_html($sector_name); ?>
                </span>
                <?php if ($status) : ?>
                    <span style="padding:4px 12px;border-radius:9999px;background:rgba(200,83,31,0.9);font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:#fff;backdrop-filter:blur(4px);box-shadow:0 2px 8px rgba(0,0,0,0.15);"><?php echo esc_html($status); ?></span>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    <div style="padding:20px 24px 24px;">
        <?php if (!$opp_img) : ?>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <span class="sector-badge"><?php if ($sector_icon) echo $sector_icon . ' '; ?><?php echo esc_html($sector_name); ?></span>
                <?php if ($status) : ?><span class="status"><?php echo esc_html($status); ?></span><?php endif; ?>
            </div>
        <?php endif; ?>
        <h3 style="margin-top:0;"><?php the_title(); ?></h3>
        <p style="margin-top:12px;font-size:14px;line-height:1.7;flex:1;"><?php echo esc_html(get_the_excerpt()); ?></p>
        <div class="meta-grid">
            <div>
                <p class="meta-label"><?php esc_html_e('Investment', 'ega'); ?></p>
                <p class="meta-value"><?php echo esc_html($amount ?: '—'); ?></p>
            </div>
            <div>
                <p class="meta-label"><?php esc_html_e('Target ROI', 'ega'); ?></p>
                <p class="meta-value ember"><?php echo esc_html($roi ?: '—'); ?></p>
            </div>
            <div>
                <p class="meta-label"><?php esc_html_e('Country', 'ega'); ?></p>
                <p style="font-weight:500;color:var(--petrol-800);"><?php echo esc_html($country_name ?: '—'); ?></p>
            </div>
            <div style="display:flex;align-items:flex-end;justify-content:flex-end;">
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" style="font-size:12px;font-weight:600;color:var(--ember-500);display:inline-flex;align-items:center;gap:6px;">
                    <?php esc_html_e('Request data room', 'ega'); ?>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </a>
            </div>
        </div>
    </div>
</div>
