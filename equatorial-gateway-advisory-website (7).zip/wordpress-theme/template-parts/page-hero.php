<?php
/**
 * Page Hero partial (with optional background image)
 * @package ega
 */
$eyebrow = $args['eyebrow'] ?? '';
$title = $args['title'] ?? '';
$lead = $args['lead'] ?? '';
$image = $args['image'] ?? '';
?>
<section class="ega-page-hero">
    <?php if ($image) : ?>
        <div style="position:absolute;inset:0;">
            <img src="<?php echo esc_url($image); ?>" alt="" loading="eager" style="width:100%;height:100%;object-fit:cover;opacity:0.3;">
            <div style="position:absolute;inset:0;background:linear-gradient(to right,var(--petrol-950),rgba(4,18,27,0.9),rgba(4,18,27,0.6));"></div>
        </div>
    <?php endif; ?>
    <div class="grid-veil" style="position:absolute;inset:0;opacity:0.2;pointer-events:none;"></div>
    <div class="glow"></div>
    <div class="ega-container" style="position:relative;">
        <div class="reveal">
            <div class="ega-heading-eyebrow"><span class="line"></span><span class="eyebrow" style="color:var(--ember-300);"><?php echo esc_html($eyebrow); ?></span></div>
        </div>
        <h1 class="reveal" data-delay="0.05"><?php echo esc_html($title); ?></h1>
        <?php if ($lead) : ?>
            <p class="lead reveal" data-delay="0.1"><?php echo esc_html($lead); ?></p>
        <?php endif; ?>
    </div>
</section>
