<?php
/**
 * Section Heading partial
 * @package ega
 */
$eyebrow = $args['eyebrow'] ?? '';
$title = $args['title'] ?? '';
$subtitle = $args['subtitle'] ?? '';
$center = !empty($args['center']);
$light = !empty($args['light']);
?>
<div class="ega-heading<?php echo $center ? ' text-center' : ''; ?>" style="<?php echo $center ? 'text-align:center;margin:0 auto;' : ''; ?>max-width:640px;">
    <div class="ega-heading-eyebrow reveal" style="<?php echo $center ? 'justify-content:center;' : ''; ?>">
        <span class="line"></span>
        <span class="eyebrow" style="color:<?php echo $light ? 'var(--ember-300)' : 'var(--ember-600)'; ?>;"><?php echo esc_html($eyebrow); ?></span>
    </div>
    <h2 class="reveal" data-delay="0.05"><?php echo esc_html($title); ?></h2>
    <?php if ($subtitle) : ?>
        <p class="subtitle reveal" data-delay="0.1"><?php echo esc_html($subtitle); ?></p>
    <?php endif; ?>
</div>
